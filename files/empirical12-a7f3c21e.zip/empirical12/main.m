
% ----------------------------------------------------------------------------
% ----------------------------------------------------------------------------

close all


clear
clc
load data/cleaneddata.mat
addpath utilities


% % In-sample analysis
% % ------------------------------------------------
% clear
% load data/cleaneddata.mat
% nlatent=3;
% minmonths=36;
% factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
% 
% nfactors=size(factors,2)+nlatent;
% 
% % Cut periods with missing factors
% f=find(isnan(sum(factors,2)));
% ret(f,:)=[];
% aum(f,:)=[];
% factors(f,:)=[];
% ymlist(f)=[];
%     
% use_in_estimation=sum(~isnan(ret))>=minmonths;
%     
% % Train
% ret_train=ret(:,use_in_estimation);
% fac=factors;
% 
% % Remove periods with too few funds
% id = sum(isnan(ret_train)');
% ymlist=ymlist(find(size(ret_train,2) - id > nfactors,1):end);
% fac=fac(find(size(ret_train,2) - id > nfactors,1):end,:);
% ret_train   =  ret_train(find(size(ret_train,2) - id > nfactors,1):end,:);
% 
% 
% %Figure of all average returns
% figure
% gg=nanmean(ret_train);
% hist(gg,50)
% xlabel('Monthly average excess returns')
% ylabel('Number of funds')
% xlim([-0.1 0.07])
% set(gca,'FontSize',18)
% save2pdf('output/avgrethist.pdf')
% close
% 
% nanmean(gg)
% nanmedian(gg)
% 
% %save(['snapshots/insample.mat'],'ret_train','fac','ymlist');
% 
% % Run estimation
% results = wrapperfuc_parfor(nlatent,ret_train',fac);
% 
% %save /tmp/tmp
% 
% select_fdr=false(size(use_in_estimation));
% select_fdr_noscreening=false(size(use_in_estimation));
% select_barras=false(size(use_in_estimation));
% select_fdr_onlylatent=false(size(use_in_estimation));
% select_fdr_naive=false(size(use_in_estimation));
% select_fdr_naive_noscreening=false(size(use_in_estimation));
% select_standard_naive=false(size(use_in_estimation));
% select_others_naive=false(size(use_in_estimation));
% select_fdr_avar=false(size(use_in_estimation));
% 
% select_fdr(find(use_in_estimation))=results.testBH_mix;
% select_fdr_noscreening(find(use_in_estimation))=results.testB_mix;
% select_barras(find(use_in_estimation))=results.testbarras;
% select_fdr_onlylatent(find(use_in_estimation))=results.testBH;
% select_fdr_naive(find(use_in_estimation))=results.testTSH;
% select_fdr_naive_noscreening(find(use_in_estimation))=results.testTS;
% select_standard_naive(find(use_in_estimation))=(results.pTS_est<=0.05);
% select_others_naive(find(use_in_estimation))=(results.pTS_est>0.05);
% select_fdr_avar(find(use_in_estimation))=results.testH;
% 
% nused=sum(use_in_estimation);
% nselect=[sum(select_fdr) sum(select_fdr_noscreening) sum(select_barras)...
%                        sum(select_fdr_onlylatent)...
%                        sum(select_fdr_naive) sum(select_fdr_naive_noscreening) sum(select_standard_naive) sum(select_others_naive) ...
%                        sum(select_fdr_avar)];
% 
% alphas=results.alpha_est;
% 
% alpha_fdr=nan(size(use_in_estimation));
% alpha_fdr_noscreening=nan(size(use_in_estimation));
% alpha_barras=nan(size(use_in_estimation));
% alpha_fdr_onlylatent=nan(size(use_in_estimation));
% alpha_fdr_naive=nan(size(use_in_estimation));
% alpha_fdr_naive_noscreening=nan(size(use_in_estimation));
% alpha_standard_naive=nan(size(use_in_estimation));
% alpha_others_naive=nan(size(use_in_estimation));
% alpha_fdr_avar=nan(size(use_in_estimation));
% 
% alpha_fdr(use_in_estimation)=alphas;
% alpha_fdr_noscreening(use_in_estimation)=alphas;
% alpha_barras(use_in_estimation)=alphas;
% alpha_fdr_onlylatent(use_in_estimation)=alphas;
% alpha_fdr_naive(use_in_estimation)=alphas;
% alpha_fdr_naive_noscreening(use_in_estimation)=alphas;
% alpha_standard_naive(use_in_estimation)=alphas;
% alpha_others_naive(use_in_estimation)=alphas;
% alpha_fdr_avar(use_in_estimation)=alphas;
% 
% alpha_fdr(~select_fdr)=NaN;
% alpha_fdr_noscreening(~select_fdr_noscreening)=NaN;
% alpha_barras(~select_barras)=NaN;
% alpha_fdr_onlylatent(~select_fdr_onlylatent)=NaN;
% alpha_fdr_naive(~select_fdr_naive)=NaN;
% alpha_fdr_naive_noscreening(~select_fdr_naive_noscreening)=NaN;
% alpha_standard_naive(~select_standard_naive)=NaN;
% alpha_others_naive(~select_others_naive)=NaN;
% alpha_fdr_avar(~select_fdr_avar)=NaN;
% 
% 
% p_fdr=nan(size(use_in_estimation));
% p_fdr_noscreening=nan(size(use_in_estimation));
% p_barras=nan(size(use_in_estimation));
% p_fdr_onlylatent=nan(size(use_in_estimation));
% p_fdr_naive=nan(size(use_in_estimation));
% p_fdr_naive_noscreening=nan(size(use_in_estimation));
% p_standard_naive=nan(size(use_in_estimation));
% p_others_naive=nan(size(use_in_estimation));
% p_fdr_avar=nan(size(use_in_estimation));
% 
% p_fdr(use_in_estimation)=results.p;
% p_fdr_noscreening(use_in_estimation)=results.p;
% p_barras(use_in_estimation)=results.p;
% p_fdr_onlylatent(use_in_estimation)=results.p;
% p_fdr_naive(use_in_estimation)=results.p;
% p_fdr_naive_noscreening(use_in_estimation)=results.p;
% p_standard_naive(use_in_estimation)=results.p;
% p_others_naive(use_in_estimation)=results.p;
% p_fdr_avar(use_in_estimation)=results.p;
% 
% p_fdr(~select_fdr)=NaN;
% p_fdr_noscreening(~select_fdr_noscreening)=NaN;
% p_barras(~select_barras)=NaN;
% p_fdr_onlylatent(~select_fdr_onlylatent)=NaN;
% p_fdr_naive(~select_fdr_naive)=NaN;
% p_fdr_naive_noscreening(~select_fdr_naive_noscreening)=NaN;
% p_standard_naive(~select_standard_naive)=NaN;
% p_others_naive(~select_others_naive)=NaN;
% p_fdr_avar(~select_fdr_avar)=NaN;
% 
% 
% t_fdr=nan(size(use_in_estimation));
% t_fdr_noscreening=nan(size(use_in_estimation));
% t_barras=nan(size(use_in_estimation));
% t_fdr_onlylatent=nan(size(use_in_estimation));
% t_fdr_naive=nan(size(use_in_estimation));
% t_fdr_naive_noscreening=nan(size(use_in_estimation));
% t_standard_naive=nan(size(use_in_estimation));
% t_others_naive=nan(size(use_in_estimation));
% t_fdr_avar=nan(size(use_in_estimation));
% 
% t_fdr(use_in_estimation)=results.alpha_est./results.se;
% t_fdr_noscreening(use_in_estimation)=results.alpha_est./results.se;
% t_barras(use_in_estimation)=results.alpha_est./results.se;
% t_fdr_onlylatent(use_in_estimation)=results.alpha_est./results.se;
% t_fdr_naive(use_in_estimation)=results.alpha_est./results.se;
% t_fdr_naive_noscreening(use_in_estimation)=results.alpha_est./results.se;
% t_standard_naive(use_in_estimation)=results.alpha_est./results.se;
% t_others_naive(use_in_estimation)=results.alpha_est./results.se;
% t_fdr_avar(use_in_estimation)=results.alpha_est./results.se;
% 
% t_fdr(~select_fdr)=NaN;
% t_fdr_noscreening(~select_fdr_noscreening)=NaN;
% t_barras(~select_barras)=NaN;
% t_fdr_onlylatent(~select_fdr_onlylatent)=NaN;
% t_fdr_naive(~select_fdr_naive)=NaN;
% t_fdr_naive_noscreening(~select_fdr_naive_noscreening)=NaN;
% t_standard_naive(~select_standard_naive)=NaN;
% t_others_naive(~select_others_naive)=NaN;
% t_fdr_avar(~select_fdr_avar)=NaN;
% 
% 
% w=nanmean(aum);
%   
% disp('1 FDR 2 FDR no screening 3 Barras 4 Onlylatent FDR 5 NaiveFDR 6 NaiveFDR_noscreening 7 NaiveStand 8 NaiveOth 9 Avar');
% 
% aums=[nansum(w(select_fdr)) nansum(w(select_fdr_noscreening)) nansum(w(select_barras))...
%                     nansum(w(select_fdr_onlylatent)) ...
%                     nansum(w(select_fdr_naive)) nansum(w(select_fdr_naive_noscreening)) nansum(w(select_standard_naive)) nansum(w(select_others_naive))...
%                     nansum(w(select_fdr_avar))];
%                  
% alpha_results=[nanmean(alpha_fdr) nanmean(alpha_fdr_noscreening) nanmean(alpha_barras) nanmean(alpha_fdr_onlylatent) nanmean(alpha_fdr_naive) nanmean(alpha_fdr_naive_noscreening) nanmean(alpha_standard_naive) nanmean(alpha_others_naive) nanmean(alpha_fdr_avar)];
% 
% t_results=[nanmean(t_fdr) nanmean(t_fdr_noscreening) nanmean(t_barras) nanmean(t_fdr_onlylatent) nanmean(t_fdr_naive) nanmean(t_fdr_naive_noscreening) nanmean(t_standard_naive) nanmean(t_others_naive) nanmean(t_fdr_avar)];
% 
% p_results=[nanmean(p_fdr) nanmean(p_fdr_noscreening) nanmean(p_barras) nanmean(p_fdr_onlylatent) nanmean(p_fdr_naive) nanmean(p_fdr_naive_noscreening) nanmean(p_standard_naive) nanmean(p_others_naive) nanmean(p_fdr_avar)];
% e
% % Results:
% % alpha_results, t_results, aum, nselect
% alpha_results=alpha_results*10000; % in bp per month
% nselect=nselect/sum(use_in_estimation)
% aums=aums/1000000000; % in bn
% 
% save output/insampleres.mat


% Recursive (OOS) analysis
% ------------------------------------------------

clear
clc

for usemodel=1:13
    
    clearvars -except usemodel
    
    valueweight=1;
    
    if usemodel==1 % Baseline (yearly rebalancing)
        load data/cleaneddata.mat
        nlatent=3;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2004;
        lastyear=2017;
        computeym=(firstyear:lastyear)'*100+12;
        NMONTHS=12;
        LAG=0;
    elseif usemodel==2 % 1 month lag
        load data/cleaneddata.mat
        nlatent=3;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2004;
        lastyear=2017;
        computeym=(firstyear:lastyear)'*100+12;
        NMONTHS=12;
        LAG=1;
    elseif usemodel==3 % 3 month lag
        load data/cleaneddata.mat
        nlatent=3;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2004;
        lastyear=2017;
        computeym=(firstyear:lastyear)'*100+12;
        NMONTHS=12;
        LAG=1;
    elseif usemodel==4 % Require 5 years
        load data/cleaneddata.mat
        nlatent=3;
        minmonths=60;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2004;
        lastyear=2017;
        computeym=(firstyear:lastyear)'*100+12;
        NMONTHS=12;
        LAG=1;
    elseif usemodel==5 % Monthly
        load data/cleaneddata.mat
        nlatent=3;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2004;
        lastyear=2018;
        computeym=[];
        for j=firstyear:lastyear
            computeym=[computeym;j*100+(1:12)'];
        end
        ff=find(computeym>201811);
        computeym(ff)=[];
        NMONTHS=1;
        LAG=0;
    elseif usemodel==6 % Monthly, 1 lag
        load data/cleaneddata.mat
        nlatent=3;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2004;
        lastyear=2018;
        computeym=[];
        for j=firstyear:lastyear
            computeym=[computeym;j*100+(1:12)'];
        end
        ff=find(computeym>201810);
        computeym(ff)=[];
        NMONTHS=1;
        LAG=1;
    elseif usemodel==7 % Monthly, 3 lag
        load data/cleaneddata.mat
        nlatent=3;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2004;
        lastyear=2018;
        computeym=[];
        for j=firstyear:lastyear
            computeym=[computeym;j*100+(1:12)'];
        end
        ff=find(computeym>201808);
        computeym(ff)=[];
        NMONTHS=1;
        LAG=3;
    elseif usemodel==8 % Use 5 latent factors
        load data/cleaneddata.mat
        nlatent=5;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2004;
        lastyear=2017;
        computeym=(firstyear:lastyear)'*100+12;
        NMONTHS=12;
        LAG=0;
   
    elseif usemodel==9 % Benchmark FF4 plus options
        load data/cleaneddata.mat
        nlatent=3;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.hml factor_ret.mom factor_ret.otmcall factor_ret.otmput];
        wind=12*10; % Lookback window for estimation
        firstyear=2006;
        lastyear=2015;
        computeym=(firstyear:lastyear)'*100+12;
        NMONTHS=12;
        LAG=0;
    elseif usemodel==10 % Evestment
        load data/cleaneddata_evestment.mat
        nlatent=4;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2007;
        lastyear=2016;
        computeym=(firstyear:lastyear)'*100+12;
        NMONTHS=12;
        LAG=0;
    elseif usemodel==11 % Evestment Monthly
        load data/cleaneddata_evestment.mat
        nlatent=4;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2007;
        lastyear=2016;
        computeym=[];
        for j=firstyear:lastyear
            computeym=[computeym;j*100+(1:12)'];
        end
        NMONTHS=1;
        LAG=0;
    elseif usemodel==12 % Only US
        load data/cleaneddata_us.mat
        nlatent=3;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2004;
        lastyear=2017;
        computeym=(firstyear:lastyear)'*100+12;
        NMONTHS=12;
        LAG=0;
    elseif usemodel==13 % Equal weighted
        load data/cleaneddata.mat
        nlatent=3;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2004;
        lastyear=2017;
        computeym=(firstyear:lastyear)'*100+12;
        NMONTHS=12;
        LAG=0;
        valueweight=0;
    end

    
    nfactors=size(factors,2)+nlatent;

    % Cut periods with missing factors
    f=find(isnan(sum(factors,2)));
    ret(f,:)=[];
    aum(f,:)=[];
    factors(f,:)=[];
    ymlist(f)=[];

    NRESULTS=9;
    
    tic
    nalive=nan(length(computeym),1);
    nused=nan(length(computeym),1);
    nselect=nan(length(computeym),NRESULTS);
    aums=nan(length(computeym),NRESULTS);
    alphas=nan(length(computeym),NRESULTS);
    alphas_monthly=nan(NMONTHS,NRESULTS,length(computeym));
    parfor jj=1:length(computeym)

        oos_start=find(ymlist==computeym(jj));
        computeym(jj)

        alive=~isnan(ret(oos_start,:)) & sum(~isnan(ret(oos_start-wind+1:oos_start,:)))>=minmonths;
        
        use_in_estimation=sum(~isnan(ret(oos_start-wind+1:oos_start,:)))>=minmonths;
    
        % Train
        ret_train=ret(oos_start-wind+1:oos_start,use_in_estimation);
        fac=factors(oos_start-wind+1:oos_start,:);

        % Remove periods with too few funds
        id = sum(isnan(ret_train)');
        fac=fac(find(size(ret_train,2) - id > nfactors,1):end,:);
        ret_train   =  ret_train(find(size(ret_train,2) - id > nfactors,1):end,:);
        
        % Run estimation
        results = wrapperfuc(nlatent,ret_train',fac);

        % Compute selected funds
        select_fdr=false(size(use_in_estimation));
        select_fdr_noscreening=false(size(use_in_estimation));
        select_barras=false(size(use_in_estimation));
        select_fdr_onlylatent=false(size(use_in_estimation));
        select_fdr_naive=false(size(use_in_estimation));
        select_fdr_naive_noscreening=false(size(use_in_estimation));
        select_standard_naive=false(size(use_in_estimation));
        select_others_naive=false(size(use_in_estimation));
        select_fdr_avar=false(size(use_in_estimation));
        
        
        select_fdr(find(use_in_estimation))=results.testBHL_mix; if sum(select_fdr & ~alive), error, end
        select_fdr_noscreening(find(use_in_estimation))=results.testBL_mix; if sum(select_fdr_noscreening & ~alive), error, end
        select_barras(find(use_in_estimation))=results.testbarras; select_barras=select_barras & alive;
        select_fdr_onlylatent(find(use_in_estimation))=results.testBHL_latent; if sum(select_fdr_onlylatent & ~alive)>0, error, end % testBHL_naive
        select_fdr_naive(find(use_in_estimation))=results.testTSHL; if sum(select_fdr_naive & ~alive), error, end
        select_fdr_naive_noscreening(find(use_in_estimation))=results.testTSL; if sum(select_fdr_naive_noscreening & ~alive), error, end
        select_standard_naive(find(use_in_estimation))=(results.pTS_est<=0.05); select_standard_naive=select_standard_naive & alive; % pB_mix pTS_est
        select_others_naive(find(use_in_estimation))=(results.pTS_est>0.05); select_others_naive=select_others_naive & alive; % pB_mix pTS_est
        select_fdr_avar(find(use_in_estimation))=results.testHL; if sum(select_fdr_avar & ~alive), error, end
        
        
        nalive(jj)=sum(alive);
        nused(jj)=sum(use_in_estimation);
        nselect(jj,:)=[sum(select_fdr) sum(select_fdr_noscreening) sum(select_barras)...
                       sum(select_fdr_onlylatent)...
                       sum(select_fdr_naive) sum(select_fdr_naive_noscreening) sum(select_standard_naive) sum(select_others_naive) ...
                       sum(select_fdr_avar)];

        % Compute betas
        betas=nan(size(use_in_estimation,2),size(results.beta,2));
        betas(use_in_estimation,:)=results.beta;
        
        w=aum(oos_start,:);
        
        if valueweight==0
            w(~isnan(w))=1;
        end   
                  
        aums(jj,:)=[nansum(w(select_fdr)) nansum(w(select_fdr_noscreening)) nansum(w(select_barras))...
                    nansum(w(select_fdr_onlylatent)) ...
                    nansum(w(select_fdr_naive)) nansum(w(select_fdr_naive_noscreening)) nansum(w(select_standard_naive)) nansum(w(select_others_naive))...
                    nansum(w(select_fdr_avar))];
                 
        alpha_oos_monthly=ret(oos_start+1+LAG:oos_start+NMONTHS+LAG,alive)-(betas(alive,:)*results.lambda)';
        
        alpha_oos_fdr_monthly=nan(NMONTHS,size(alive,2));
        alpha_oos_fdr_noscreening_monthly=nan(NMONTHS,size(alive,2));
        alpha_oos_barras_monthly=nan(NMONTHS,size(alive,2));
        alpha_oos_fdr_onlylatent_monthly=nan(NMONTHS,size(alive,2));
        alpha_oos_fdr_naive_monthly=nan(NMONTHS,size(alive,2));
        alpha_oos_fdr_naive_noscreening_monthly=nan(NMONTHS,size(alive,2));
        alpha_oos_standard_naive_monthly=nan(NMONTHS,size(alive,2));
        alpha_oos_others_naive_monthly=nan(NMONTHS,size(alive,2));
        alpha_oos_fdr_avar_monthly=nan(NMONTHS,size(alive,2));
        
        alpha_oos_fdr_monthly(:,alive)=alpha_oos_monthly;
        alpha_oos_fdr_noscreening_monthly(:,alive)=alpha_oos_monthly;
        alpha_oos_barras_monthly(:,alive)=alpha_oos_monthly;
        alpha_oos_fdr_onlylatent_monthly(:,alive)=alpha_oos_monthly;
        alpha_oos_fdr_naive_monthly(:,alive)=alpha_oos_monthly;
        alpha_oos_fdr_naive_noscreening_monthly(:,alive)=alpha_oos_monthly;
        alpha_oos_standard_naive_monthly(:,alive)=alpha_oos_monthly;
        alpha_oos_others_naive_monthly(:,alive)=alpha_oos_monthly;
        alpha_oos_fdr_avar_monthly(:,alive)=alpha_oos_monthly;
               
        alpha_oos_fdr_monthly(:,~(select_fdr & alive))=NaN;     
        alpha_oos_fdr_noscreening_monthly(:,~(select_fdr_noscreening & alive))=NaN;        
        alpha_oos_barras_monthly(:,~(select_barras & alive))=NaN;        
        alpha_oos_fdr_onlylatent_monthly(:,~(select_fdr_onlylatent & alive))=NaN;      
        alpha_oos_fdr_naive_monthly(:,~(select_fdr_naive & alive))=NaN;        
        alpha_oos_fdr_naive_noscreening_monthly(:,~(select_fdr_naive_noscreening & alive))=NaN;        
        alpha_oos_standard_naive_monthly(:,~(select_standard_naive & alive))=NaN;        
        alpha_oos_others_naive_monthly(:,~(select_others_naive & alive))=NaN;
        alpha_oos_fdr_avar_monthly(:,~(select_fdr_avar & alive))=NaN;
        
        alphas_monthly(:,:,jj)=[nansum(w.*alpha_oos_fdr_monthly,2)/nansum(w.*~isnan(alpha_oos_fdr_monthly(1,:))) nansum(w.*alpha_oos_fdr_noscreening_monthly,2)/nansum(w.*~isnan(alpha_oos_fdr_noscreening_monthly(1,:))) nansum(w.*alpha_oos_barras_monthly,2)/nansum(w.*~isnan(alpha_oos_barras_monthly(1,:)))...
                      nansum(w.*alpha_oos_fdr_onlylatent_monthly,2)/nansum(w.*~isnan(alpha_oos_fdr_onlylatent_monthly(1,:))) ...
                      nansum(w.*alpha_oos_fdr_naive_monthly,2)/nansum(w.*~isnan(alpha_oos_fdr_naive_monthly(1,:))) nansum(w.*alpha_oos_fdr_naive_noscreening_monthly,2)/nansum(w.*~isnan(alpha_oos_fdr_naive_noscreening_monthly(1,:))) nansum(w.*alpha_oos_standard_naive_monthly,2)/nansum(w.*~isnan(alpha_oos_standard_naive_monthly(1,:))) nansum(w.*alpha_oos_others_naive_monthly,2)/nansum(w.*~isnan(alpha_oos_others_naive_monthly(1,:)))   ...
                      nansum(w.*alpha_oos_fdr_avar_monthly,2)/nansum(w.*~isnan(alpha_oos_fdr_avar_monthly(1,:)))];
        
        
    end
    
    toc
    
    splitA = num2cell(alphas_monthly, [1 2]);
    alphas_monthly=vertcat(splitA{:});
    
    alphas_monthly(isnan(alphas_monthly))=0;
    alphas(isnan(alphas))=0;
    aums(isnan(aums))=0;

    disp('alphas')
    disp('1 FDR 2 FDR no screening 3 Barras 4 Onlylatent FDR 5 NaiveFDR 6 NaiveFDR_noscreening 7 NaiveStand 8 NaiveOth 9 Avar');
    12*mean(alphas_monthly)
     
    disp('nalive')
    mean(nalive)
    
    disp('nused')
    mean(nused)

    disp('fraction select')
    mean(nselect./nalive)

    disp('AUM')
    mean(aums/1000000)
    
    save(['output/res_' num2str(usemodel)]);
    
end    

