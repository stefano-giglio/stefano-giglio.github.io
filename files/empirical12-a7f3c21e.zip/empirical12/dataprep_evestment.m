addpath utilities

clear
clc

data_factors=readtable('data_orig/factors.xls');
data_ret=readtable('data_orig/fundret_evestment.csv');

data_ret=sortrows(data_ret,{'id','ym'});

data_factors=data_factors(data_factors.ym<=max(data_ret.ym),:);
data_ret=data_ret(data_ret.ym>=199401,:);

ym=data_factors.ym;
ym=sort(ym); % Just make sure it's sorted

% Add index of month in addition for ym, where first month in ym is 1, etc
ym_index=nan(length(data_ret.ym),1);
for j=1:length(ym)
    f=find(data_ret.ym==ym(j));
    ym_index(f)=j;
end

fundlist=unique(data_ret.id);

ret=nan(length(ym),length(fundlist));
aum=nan(length(ym),length(fundlist));

for j=1:length(fundlist)
    
    j
    
    f=find(data_ret.id==fundlist(j));
    temp_ret=data_ret.ret(f);
    temp_aum=data_ret.aum(f);
    temp_ym=ym_index(f);

    ret(temp_ym,j)=temp_ret;
    aum(temp_ym,j)=temp_aum;
    
end

factor_ret=data_factors(:,2:end);

ymlist=ym;

% Fill in monthly AUM from quarterly
for j=1:size(aum,2)
    
    temp=aum(:,j);
    eoq=mod(ymlist,100)==3 | mod(ymlist,100)==6 | mod(ymlist,100)==9 | mod(ymlist,100)==12;
    for i=1:length(temp)-2
        if eoq(i) && ~isnan(temp(i)) && isnan(temp(i+1))
            temp(i+1)=temp(i);
        end
        
        if eoq(i) && ~isnan(temp(i+1)) && isnan(temp(i+2))
            temp(i+2)=temp(i+1);
        end
        
    end
    aum(:,j)=temp;
            
end

save data/maindata_evestment.mat ret aum ymlist factor_ret

clear
load data/maindata_evestment.mat
mincorr=0.99;
cutoff=10;

% Remove data after they drop below $cutoff million AUM (today's dollars)
% We keep the first observation after the drop to avoid bias
for j=1:size(aum,2)
    f=find(aum(:,j)<cutoff);
    if ~isempty(f)
        ret(f(1)+1:end,j)=NaN;
        aum(f(1)+1:end,j)=NaN;
    end
end

% 10-fold increase in a month
dropfund=[];
for k=1:size(aum,2)
    temp=aum(:,k);
    temp=temp(2:end)./temp(1:end-1); 
    if max(temp)>10
        dropfund=[dropfund;k];
    end
end

dropfund=unique(dropfund);
ret(:,dropfund)=[];
aum(:,dropfund)=[];

% 100-fold increase in 1 year
dropfund=[];
for k=1:size(aum,2)
    temp=aum(:,k);
    temp=temp(13:end)./temp(1:end-12); 
    if max(temp)>100
        dropfund=[dropfund;k];
    end
end

dropfund=unique(dropfund);
ret(:,dropfund)=[];
aum(:,dropfund)=[];

% This is half trillion
f=find(nanmin(aum)>500000); 
ret(:,f)=[];
aum(:,f)=[];


A=repmat((1:size(ret,1))',1,size(ret,2));
A(isnan(ret))=NaN;
first=min(A);
last=max(A);
totmonths_ret=last-first+1;
totmonths_ret(isnan(totmonths_ret))=0;

nmis_ret=nan(1,size(ret,2));
% Count missing
for j=1:size(ret,2)
    
    if totmonths_ret(j)>0
        temp=A(first(j):last(j),j);
        nmis_ret(1,j)=length(find(isnan(temp)));
    else
        nmis_ret(1,j)=NaN;
    end
    
end

A=repmat((1:size(aum,1))',1,size(aum,2));
A(isnan(aum))=NaN;
nmis_aum=nan(1,size(aum,2));
% Count missing
for j=1:size(aum,2)
    if totmonths_ret(j)>0
        temp=A(first(j):last(j),j);
        nmis_aum(1,j)=length(find(isnan(temp)));
    else
        nmis_aum(1,j)=NaN;
    end
end


% Require at least 24 months of data
navail_ret=sum(~isnan(ret));
f1=(navail_ret<24);

f2=(nmis_aum./totmonths_ret)>0.05 | isnan(nmis_aum);

f3=(nmis_ret./totmonths_ret)>0.05 | isnan(nmis_ret);

ret(:,f1 | f2 | f3)=[];
aum(:,f1 | f2 | f3)=[];


% Produce excess returns
ret=ret-factor_ret.rf;

% Remove periods with no funds
f=find(sum(~isnan(ret),2)==0);
ret(f,:)=[];
aum(f,:)=[];
ymlist(f,:)=[];
factor_ret(f,:)=[];

% Find and remove duplicates
% ------------------------------------------------
nc=corrcoef(ret,'Rows','pairwise');
f=find(eye(size(nc)));
nc(f)=NaN;
[ii,jj]=find(nc>mincorr);
pairs=[ii jj];
pairs=pairs(pairs(:,1)<pairs(:,2),:);

% Remove cases where overlap was minimal, which generates high correlation
for l=1:length(pairs)
    tempret=[ret(:,pairs(l,1)) ret(:,pairs(l,2))];
    overlap(l,1)=sum(~isnan(sum(tempret,2)));
end

% Require at least 12 months of common data, with corr > 0.99
pairs(overlap<12,:)=[];

% Remove the one with the least amount of data
removelist=[];
for l=1:length(pairs)

    tempret=[ret(:,pairs(l,1)) ret(:,pairs(l,2))];

    if sum(~isnan(tempret(:,2)))>sum(~isnan(tempret(:,1)))
        removelist=[removelist;pairs(l,1)];
    elseif sum(~isnan(tempret(:,2)))<sum(~isnan(tempret(:,1)))
        removelist=[removelist;pairs(l,2)];
    elseif sum(~isnan(tempret(:,2)))==sum(~isnan(tempret(:,1)))
        % If same length, always remove the one with smallest id, so we don't risk eliminating all
        removelist=[removelist;pairs(l,1)]; 
    end
end
removelist=unique(removelist);

ret(:,removelist)=[];
aum(:,removelist)=[];

save data/cleaneddata_evestment.mat ret aum factor_ret ymlist