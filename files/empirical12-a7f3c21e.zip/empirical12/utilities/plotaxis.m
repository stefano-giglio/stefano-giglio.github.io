function plot1 = plotaxis(xlabels,numticks)

if nargin==1 || isempty(numticks),
    numticks = 10;
end

T     = length(xlabels);

if strcmp(numticks,'years')
    mo=xlabels-floor(xlabels/100)*100;
    f=find(mo==1);
    ticks=f;
    xlabels=floor(xlabels/100);
else
    space = floor(T/numticks);
    ticks = [1,space:space:T];
end
   
ticks=unique(ticks);
set(gca,'XTick',ticks,'XTickLabel',xlabels(ticks))
xlim([0 T+1]);
set(gca,'fontname','Times New Roman','fontSize',16);
