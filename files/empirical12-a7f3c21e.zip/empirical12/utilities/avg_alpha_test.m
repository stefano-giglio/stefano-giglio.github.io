function [testI1,testI2, testdf, alphaI1, alphaI2, alphadf] =avg_alpha_test(alpha, beta_est, I1, I2, var1)

%  I1 is Nx1 index set
%  I2 is Nx1 index set that can be empty
%  testI1 is test of avg alpha over I1
%  testI2 is test of avg alpha over I2
%  testdf is test of difference of avg alphas between I1 and I2


    [N, K] = size(beta_est);    
    M_N= eye(N) - ones(N,N)/N;
    Sb  = (beta_est'*M_N*beta_est)/N;
    sigma_alpha = std(alpha);
    
    
    XI = diag(var1) + 1/N*sigma_alpha^2*beta_est*inv(Sb)*beta_est';
        
    alphaI1 = mean(alpha(I1));    
    avarI1  = I1'*XI*I1/(sum(I1))^2;  
     
    testI1  = abs(alphaI1)/sqrt(avarI1);
    
    testI2 = nan;
    testdf = nan;
    alphadf = nan;
    alphaI2 = nan;
    
    if ~isnan(I2)
        
        
     
        alphaI2 = mean(alpha(I2));    
        avarI2  = I2'*XI*I2/(sum(I2))^2;  
        testI2  = abs(alphaI2)/sqrt(avarI2);
        
        alphadf = mean(alpha(I1)) - mean(alpha(I2));
        M      = I1/sum(I1) - I2/sum(I2);
        avardf  = (M'*XI*M); 
        testdf  = (alphadf)/sqrt(avardf);
    
    end





end