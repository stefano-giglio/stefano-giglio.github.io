% this function is used to do matrix completion
% The model: factor model, after demeaned 
% Z= Loading * factor +error


% input: Z: N by T of data, with possible missing
%        K: number of factors
%        X: N by T indicating whether missing or not. X==1 : observed.
%       sigmau: N by 1 vector of error variances
% output: loading: N by K: estimated loadings
%        
% this is the _v4 version (latest)
function [loading, F] = matrix_completion(Z,X, K, sigmau)

[N, T]      = size(Z);
stepsize= 0.9; %  shoul be between 0 and 1, close to 1. 
 %load=nan(N,K,2);
  
 noise=diag(sqrt(sigmau))*randn(N,T);
  tuning= norm(noise.*X,2)*2.2;
     threshold= stepsize*tuning/2;
      M=Z;
     diff=10;
     
 %%

     
  %%  iterative LS no sample splitting
 
    % 
   while diff >1e-9  
         Mold=M;
         A= M- X.*(X.*M-Z)*stepsize;
           [V1,S1]= eigs(A'*A,K*2); % T by K
         D1=sqrt(S1);
         U1=A*V1*inv(D1);
         D1new=(D1-threshold).*(D1>threshold);
         M= U1*D1new*V1';
         diff= norm(M-Mold)/sqrt(N*T) ;
        end % while
     Lambda= U1(:,1:K)*sqrt(N); % initial eigenvector
     F=nan(K,T);
       for t=1:T
         F(:,t)=(Lambda'*diag(X(:,t))*Lambda)\Lambda'*diag(X(:,t))*Z(:,t);
       end
     loading=nan(N,K);
     for i=1:N
         loading(i,:)= Z(i,:)*diag(X(i,:))*F'/(F*diag(X(i,:))*F'); 
     end
 
  
     
     %% method 4 sample splitting
     
 %{
 for l=1: 2
     
      %% sample splitting
     
     set1= [1:round(T/2)];
     set2= [round(T/2)+1:T];
     
     if l ==1
         training= set1;
         test = set2;
     else 
         training =set2;
         test= set1;
     end % if
     
     %% regularized estimation on training
     Xtraining= X(:,training);
     Ztraining= Z(:,training);
    
     %{
    U=randn(N,T);
     tuning= norm(U.*Xtraining,2)*2.2*sqrt(sigmau);
     threshold= stepsize*tuning/2;
      M=Ztraining;
     diff=10;
        while diff >1e-9  
         Mold=M;
         A= M- Xtraining.*(Xtraining.*M-Ztraining)*stepsize;
         [V1,S1]= eigs(A'*A,K*2); % T/2 by K
         D1=sqrt(S1);
         U1=A*V1*inv(D1);
         D1new=(D1-threshold).*(D1>threshold);
         M= U1*D1new*V1';
         diff= norm(M-Mold)/sqrt(N*T/2) ;
        end % while
     Lambda= U1(:,1:K)*sqrt(N); % initial eigenvector
     %}
     
     %% update Loading on test
     
     Xtest= X(:,test);
     Ztest=Z(:,test);
     F=nan(K,length(test));
    
     for t=1:length(test)
         F(:,t)=(Lambda'*diag(Xtest(:,t))*Lambda)\Lambda'*diag(Xtest(:,t))*Ztest(:,t);
     end
     for i=1:N
         load(i,:,l)= Ztest(i,:)*diag(Xtest(i,:))*F'/(F*diag(Xtest(i,:))*F'); 
     end
     
 end % l =1,2
 
 %% output
 
     loading =mean(load,3);
     
 %for t=1:T
 % factor(:,t)=(loading'*diag(X(:,t))*loading)\loading'*diag(X(:,t))*Z(:,t);
 %end
 %}
  
%{
cvx_begin
variable Xe(N,T)
minimize norm_nuc(Xe)
subject to
norm(Z-X.*Xe,'fro')<sigmau*sum(X(:));
cvx_end
%}
 
 