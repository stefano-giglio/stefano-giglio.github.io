% This code estimates alpha when there are NO observed factors. So only latent factors

% Model:  R_t= alpha+ beta*gamma+    beta * g_t + u_t  
%         
%   Here g_t is a vector of latent factors

% Let N = number of funds
%     T = number of time points
% Input:   R: N by T , matrix of returns R_t. R is NOT de-meaned. This code  will de-mean it for you.
%          K: the number of latent factors. Can either mannually set,
%              or use the following code to choose (data dependent choice)

%{
%% data dependent choice of K, no need to run this part if mannually choose K
 [  N, T]      = size(R);
   demeanR     = R-mean(R,2)*ones(1,T); % N by T
   Sam_cov     = demeanR*demeanR'/T;
   [u,v]=eig(Sam_cov);
   value=sort(diag(v),'descend');
   ratio=value(1:10)./value(2:11);
   [d,K]=max(ratio);

%}


% Output: alpha: N by 1, the estimated alpha
%         se:    N by 1, standard errors
%          t:   alpha/se,   N by 1 vector of t-satistics
 
function [alpha, alpha0, se, se0, t, t0, eigs] =alpha_latent_v1(R, K)

   [N, T]      = size(R);
   Rbar     =  R - nanmean(R,2)*ones(1,T);%R-mean(R,2)*ones(1,T); % N by T
   Sam_cov     =  cov(Rbar','partialrows');%demeanR*demeanR'/T;
   
   Sam_cov(isnan(Sam_cov))=0;
       
       [tempV,tempD]         =      eig(Sam_cov/N);  % n < T? 
       [tempeig,tempidx]     =      sort(real(diag(tempD)),'descend');
       eigvec                =      tempV(:,tempidx); 
       u1                    =      eigvec(:,1:K);
       v1                    =      diag(tempeig(1:K));   
       
       eigs=tempeig;
       
 %  [u1,v1]     = eigs(Sam_cov/N,K);
   beta_est    = u1*sqrt(N);     
   Miota      = eye(N) - 1/N*ones(N,1)*ones(1,N);
   Mbeta      = eye(N) - beta_est*inv(beta_est'*beta_est)*beta_est';
   lambda     = (beta_est'*Miota*beta_est)\(beta_est'*Miota*nanmean(R,2));
   alpha0     = (ones(N,1)'*Mbeta*ones(N,1))\(ones(N,1)'*Mbeta*nanmean(R,2));
   
   alpha     = nanmean(R,2)-beta_est*lambda;
   
   
   %  standard error of alpha
   nanidx           = isnan(R);
   Rtemp            = Rbar; 
   Rtemp(nanidx)    = 0; 
   factor_pca       = Rtemp'*beta_est./repmat(N-sum(nanidx,1)',1,K); % T by K  
%   factor_pca  = demeanR'*beta_pca/N; % T by K  
   U_pca       = Rbar- beta_est*factor_pca'  ; % N by T
   ml          = ones(N,1)*(ones(1,T)- lambda'*inv(v1)*factor_pca')   ; % N by T
   bl          = (U_pca.^2).*(ml.^2); % N by T
   sigma12     = nanmean(bl,2);
   D_beta           = beta_est'*Miota*beta_est;  
   sigma22          = diag((beta_est*inv(D_beta)*beta_est')* ((alpha -mean(alpha))'*(alpha -mean(alpha)))) ;  % N by 1

   
  % sigma22     = diag(beta_pca*beta_pca' )* alpha'*alpha/N  ;
  %sigma22     = diag(beta_pca*beta_pca' - mean(beta_pca,2)*mean(beta_pca,2))* alpha'*alpha/N  ;
 % Output: 
 
  se     = sqrt(sigma12./( T - sum(isnan(R),2))  +  sigma22/N );  % N by 1
        t      = alpha./se   ; % t statistics, N by 1
        
        se0    = sqrt(inv((1 - mean(beta_est,1)*inv(beta_est'*beta_est/N)*mean(beta_est,1)'))*(alpha -mean(alpha))'*(alpha -mean(alpha)))/N; 
        t0     = alpha0./se0   ;    
