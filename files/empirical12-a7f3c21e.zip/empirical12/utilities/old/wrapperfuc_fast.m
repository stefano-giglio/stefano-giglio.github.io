function results = wrapperfuc_fast(K,R,F)

%Input: R  NxT matrix of returns. Missing is NaN.
%       F  Txr matrix of factors. No Missing.
%       K  number of latent factors.

%Output: results.test : our baseline result using observable and latentfactors
%        restlts.testH: same as above, with alpha screening
%        results.alpha_est: same as above, alpha estimates
%        results.se:        same as above, se
%        resutlts.tstats:   same as above, tstats

%        results.testnaive  : our baseline result with omitted factors
%        restlts.testHnaive: same as above, with alpha screening   %USELESS
%        results.alpha_estnaive: same as above, alpha estimates
%        results.senaive:        same as above, se
%        resutlts.tstatsnaive:   same as above, tstats

%        results.testlatent: our baseline result using latent factors only
%        restlts.testHlatent: same as above, with alpha screening
%        results.alpha_estlatent: same as above, alpha estimates
%        results.selatent:        same as above, se
%        resutlts.tstatslatent:   same as above, tstats


%        results.testB      : our bootstrap result using latent factors only
%        results.testB_mix  : our baseline result using observable and latent factors


   B        =  2000;
   [N, T]   =  size(R);
   r        =  size(F,2);
   KK       =  K+r;
   
   Rbar     =  R - repmat(nanmean(R,2),1,T);% 
   Rbar(isnan(R)) = 0;
   
   [U,S,V]  =  svd(Rbar/sqrt(N)/sqrt(T),'econ');
   vhat     =  T^0.5  * V(:,1:KK)';
   betahat  =  T^(-1) * Rbar * vhat';
   Ubar     =  Rbar - betahat*vhat;
   Sigma_uhat = ((Ubar*Ubar')/T);
   
   
   

%% Estimation 
  % sc  = 2;  %scenario 1 or 2

 
  
   [results.test,results.testH,  results.se, results.alpha_est, results.p,results.beta,results.factor,results.lambda,results.testHL]   = indi_avar_missing_new(R, F, K, diag(Sigma_uhat),   0.05);% =  fdrcontrol_MC(1, K, R, F, 0.05, sc, diag(Sigma_uhat));
    
   %[results.testnaive, results.testHnaive,  results.senaive, results.alpha_estnaive, results.pnaive, ~, ~, ~, results.testHLnaive]      = indi_avar_missing_new(R, F, 0, diag(Sigma_uhat),   0.05);% fdrcontrol_MC(1, 0, R, F, 0.05,sc,diag(Sigma_uhat));
   
   %[results.testlatent, results.testHlatent,  results.selatent, results.alpha_estlatent,  results.platent]=  indi_avar_missing_new(R, [], KK, diag(Sigma_uhat),   0.05);%fdrcontrol_MC(0, KK, R, F, 0.05,sc,diag(Sigma_uhat));
   
   %[results.testB, results.testBH,  results.alpha_boot_latent,  results.alpha_estB, results.pB, results.testBHL_latent]           =   indi_bootstrap_missing_new(R, [], KK, diag(Sigma_uhat), B, 1, 0.05);%wildbootstrap_missing_latent(R,  KK, diag(Sigma_uhat), B, 0.05);

   %[results.testB_mix,results.testBH_mix, results.alpha_boot_mix, results.alpha_estB_mix, results.pB_mix,results.testBHL_mix] =   indi_bootstrap_missing_new(R, F, K, diag(Sigma_uhat), B, 1, 0.05);%wildbootstrap_missing_mix(R, F, K,  diag(Sigma_uhat), B, 0.05);
   
   %[results.testB_naive,results.testBH_naive, results.alpha_boot_naive, results.alpha_estB_naive, results.pB_naive, results.testBHL_naive] =   indi_bootstrap_missing_new(R, F, 0, diag(Sigma_uhat), B, 1, 0.05);%wildbootstrap_missing_mix(R, F, K,  diag(Sigma_uhat), B, 0.05);

   %[results.testTS, ~ , results.alphaTS_est, results.pTS_est,results.testTSL]=naive_bootstrap_TSonly(R, F,  B, 0.05);
   
   %[results.testbarras, ~ , results.alphabarras_est,results.pbarras_est]=barras2(R, F, B, 0.05, 0.6, [0.01,0.02, 0.05, 0.1, 0.15, 0.2,0.35, 0.45]);

end