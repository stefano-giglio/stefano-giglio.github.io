% this implement Harvey and Liu 2018
% input:
%         R: N by T of returns, may have missing
%         Fo: K by T common factors
%         p0: the proportion of true positive alphas "one guess".
 %            try p0=0.1
%        tau: designated FDR rate


function test= HarveyandLiu( R  ,Fo, p0, tau)


 
   X           = ~isnan(R);% ~= 0;    % Feb 3 , 2020
  R_obs=R;   % Feb 3 , 2020
    [N, T]                = size(R_obs);
   R_obs(isnan(R_obs)) = 0;   % Feb 3 , 2020
     aveR_ind             = sum(R_obs,2)./sum(X,2); 
    Rbar     =  R_obs -  aveR_ind  *ones(1,T);
 Fo=Fo';
      K=length(Fo(:,1));     % Feb 3 , 2020
 
      betao_est=nan(N,K);
             Vo=Fo-mean(Fo,2)*ones(1,T);
            for i=1:N
               index=find(X(i,:));
              d=sum(X(i,:));
              M_xi= eye(d) -ones(d,d)/d;
              factor=Fo(:,index);
              betao_est(i,:)= R_obs(i,index)*M_xi*factor'/(factor*M_xi*factor');  
            end % i
            beta_est=betao_est;
            factor_est= Vo;
             residual = (Rbar - beta_est*factor_est).*X; % N by T, with missing
     
     M_N= eye(N) - ones(N,N)/N;
     Pbeta= (beta_est'*M_N*beta_est)\beta_est'*M_N;
     lambda_est= Pbeta*aveR_ind  ;   % factor risk premia
     
     alpha=aveR_ind  - beta_est*lambda_est ;
     
     %% se 
  S_f=factor_est*factor_est'/T;
            var1=nan(N,1);
         
           for h=1:N
                index=find(X(h,:));
                d=sum(X(h,:));
                   su=residual(h,index)*residual(h,index)'/d; % method 2,3
                 var1(h)= su*norm(1-lambda_est'/S_f* factor_est(:,index))^2/d^2; % metthod 
           end % h
    se=sqrt(var1);
     tstat=alpha./se;
     
  
     
      I=100;
      J=1000; 
        FDP=nan(N,I,J);
      parfor i=1:I
          
         
           resample_index = randsample(T,T,1);  
           F_boot         = Fo(:,resample_index);
        X_boot         =X(:,resample_index); % Feb 3
           R_boot         =R_obs(:,resample_index);
 
     %[alpha,se, tstat_boot]=alpha_missing_obs(R_boot,X_boot,F_boot); % N by 1   % Feb 3 , 2020
    
     
     
     
      betao_est=nan(N,K);
             Vo= F_boot -mean( F_boot ,2)*ones(1,T);
            for h=1:N
               index=find( X_boot(h,:));
              d=sum( X_boot(h,:));
              M_xi= eye(d) -ones(d,d)/d;
              factor=F_boot(:,index);
              betao_est(h,:)= R_boot(h,index)*M_xi*factor'/(factor*M_xi*factor');  
            end % h
            beta_est=betao_est;
            factor_est= Vo;
             aveR_ind             = sum( R_boot,2)./sum(X_boot,2); 
    Rbar     =   R_boot -  aveR_ind  *ones(1,T);
             residual = (Rbar - beta_est*factor_est).*X_boot; % N by T, with missing
     
     
     Pbeta= (beta_est'*M_N*beta_est)\beta_est'*M_N;
     lambda_est= Pbeta*aveR_ind  ;   % factor risk premia
     
     alpha=aveR_ind  - beta_est*lambda_est ;
     
    
  S_f=factor_est*factor_est'/T;
            var1=nan(N,1);
         
           for h=1:N
                index=find(X_boot(h,:));
                d=sum(X_boot(h,:));
                   su=residual(h,index)*residual(h,index)'/d; % method 2,3
                 var1(h)= su*norm(1-lambda_est'/S_f* factor_est(:,index))^2/d^2; % metthod 
           end % h
    se=sqrt(var1);
    tstat_boot=alpha./se;
     
   
         
         
         [t_sort,skill_index ] = sort(tstat_boot, 'descend'); % N by 1 % max to min    
         %true_skill = skill_index(1:round(p0*N));  % alternative
         no_skill = skill_index(round(p0*N)+1:end); % null
         %Y=R_obs;  % Feb 3 , 2020
         Y= R_obs;
          demeanedR=(R_obs- (sum(R_obs,2)./sum(X,2))*ones(1,T)).*X;  % Feb 3, 2020
         Y(no_skill,:)=demeanedR(no_skill,:);
      %   Y=[R_obs(true_skill,:); demeanedR(no_skill,:)] ; 
          
             %%  resample Y
             for j=1:J
                 resample_index = randsample(T,T,1);  
                 F_boot         = Fo(:,resample_index);
                X_boot         =X(:,resample_index); % Feb 3, 2020
                Y_boot         =Y(:,resample_index);
               %  [alpha,se,  tstat_boot2]=alpha_missing_obs(Y_boot,X_boot,F_boot); % N by 1,  % Feb 3, 2020
                
               
               
               
               
      betao_est=nan(N,K);
             Vo= F_boot -mean( F_boot ,2)*ones(1,T);
            for h=1:N
               index=find( X_boot(h,:));
              d=sum( X_boot(h,:));
              M_xi= eye(d) -ones(d,d)/d;
              factor=F_boot(:,index);
              betao_est(h,:)= Y_boot(h,index)*M_xi*factor'/(factor*M_xi*factor');  
            end % h
            beta_est=betao_est;
            factor_est= Vo;
             aveR_ind             = sum( Y_boot,2)./sum(X_boot,2); 
    Rbar     =   Y_boot -  aveR_ind  *ones(1,T);
             residual = (Rbar - beta_est*factor_est).*X_boot; % N by T, with missing
     
     
     Pbeta= (beta_est'*M_N*beta_est)\beta_est'*M_N;
     lambda_est= Pbeta*aveR_ind  ;   % factor risk premia
     
     alpha=aveR_ind  - beta_est*lambda_est ;
     
    
  S_f=factor_est*factor_est'/T;
            var1=nan(N,1);
         
           for h=1:N
                index=find(X_boot(h,:));
                d=sum(X_boot(h,:));
                   su=residual(h,index)*residual(h,index)'/d; % method 2,3
                 var1(h)= su*norm(1-lambda_est'/S_f* factor_est(:,index))^2/d^2; % metthod 
           end % h
    se=sqrt(var1);
   
               
                tstat_boot2=alpha./se;
               
              
              
               testk= tstat_boot2*ones(1,N)>ones(N,1)*tstat'; % N by N % columns are for different cutoffs; rows are for different alphas
                  false_discov= sum(testk(no_skill,:),1); % 1 by N, false reject num for each cutoff. 
                  discovery= max( sum(testk,1),1); % 1 by N, num rejections for each cutoff
                  FDP(:,i,j)= (false_discov./discovery)'; % N by 1 for each cutoff
                
                
             end % j
             
           
             i
            
      end % i
      
      
      
    FDR_est=  sum(sum(FDP,3),2)/(I*J); % N by 1, for each cutoff
    [r,index]=min(abs(FDR_est-tau));  % closest to tau
      test= tstat>tstat(index);
      
      
      
      
      
      
      
      
      