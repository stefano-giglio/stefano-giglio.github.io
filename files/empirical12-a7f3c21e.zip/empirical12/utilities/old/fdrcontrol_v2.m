 
% This code tests each of N alphas whether to reject or not. It does FDR control, so that FDR <= tau
% Model:  R_t= alpha+ beta*gamma +    beta * g_t (observ) + u_t  % no omitted factors
% Model:  R_t= alpha+ beta*gamma +   beta1 * g_t(observ) +  beta2 * g_t(latent) + u_t   % mixed

%  The null:          H_0: alpha <=0 
%  The alternative:   H_0: alpha >0

% Let N = number of funds
%     T = number of time points
%     r = number of observed factors

% inputs: 
%
%       tau  :     significant level to control.
%                  often tau = 0.05

%      obser :     whether there are observable factors or not
%                  obser=1 there are observ factors
%                  obser=0 there are no observ factors

%     K     :    the number of LATENT factors, mannually set.
%                 Set K=0 if there are NO latent factors. 

 
%       R    :     N by T , matrix of returns R_t. R is NOT de-meaned. 
%       F    :     T by r,  matrix of observed factors.
%                  If obser=0, there are no observed factors, input anything, such  as F=1
%       



% output:  

% test:     N by 1, it gives whether each of the N tests should be
                         % rejected or not
%           test ==1 means reject; 
%           test ==0 means accept
%          

% alpha:    N by 1, the estimated alpha
% alpha0:   1 by 1, the estimated cross-sectional mean of alpha
% se:       N by 1, standard errors
% se0:      1 by 1, standard error of alpha0
% t:        alpha/se,   N by 1 vector of t-satistics of alpha
% t0:       alpha0/se0, 1 by 1, t-satistics of alpha0

function [test, alpha, alpha0,  se, se0, t, t0, eigs] = fdrcontrol_v2(obser, K, R, F, tau)

switch obser
    case 1 % there are observ factors

        [alpha, alpha0, se, se0, t, t0, betahat, se_low,eigs] = alpha_mixed_v2(R, F, K);
        
      %  bias =  - betahat*inv(betahat'*betahat)*betahat'*alphatr;
        
    case 0 % No observ factors
        
        [alpha, alpha0, se, se0, t, t0, eigs] =   alpha_latent_v1(R, K);
        
end % switch

 [N, T]   = size(R);
  test    = zeros(N,1); 
  set     = (t> - sqrt(log(log(N))));
  new_t   = t(set);  % selected t stats, only focus on this set
  new_N   = sum(set); % number of selected
  dind    = [1:N]';
  index   = dind(set); % index of those selected t stats
  
  if  new_N>0  % there are t > - sqrt(log(log(N)))
  
        p       =  1-normcdf(new_t); % p-value
        p_sort  = sort(p, 'ascend'); 
        k_hat   = max((p_sort<=[1:new_N]'*tau/new_N).*[1:new_N]');
        
        if k_hat>0  % there are reject
            
            rejec_index        = index(p<=p_sort(k_hat));         
            test(rejec_index)  = ones(length(rejec_index),1);
        end
        
  end
  
%{
 
older version, do not do selection; lower power
  
  switch obser
    case 1 % there are observ factors

        [alpha, se, t]=alpha_mixed(R, F, K);
        
    case 0 % No observ factors
        [alpha, se, t]=alpha_latent(R, K);
        
end % switch
  
       [N, T]   = size(R);
       test     = zeros(N,1);
 
 
        p       =  1-normcdf(t); % p-value
        p_sort  = sort(p, 'ascend'); 
        k_hat   = max((p_sort<=[1:N]'*tau/N).*[1:N]');
       
        if k_hat>0  % there are reject
            
            test           = (p<=p_sort(k_hat));         
            
        end
        
  end
  
  %}
    
   