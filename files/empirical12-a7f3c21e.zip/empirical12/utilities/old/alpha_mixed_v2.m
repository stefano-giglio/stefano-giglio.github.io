% This code estimates alpha when there are both observed and latent
% factors, or observed factors only. So there MUST be observed factors to
% run this code.

% Model:  R_t= alpha+ beta*gamma + beta1 * g_t(observed) +  beta2 * g_t(latent) + u_t  
%         
% 

% Let N = number of funds
%     T = number of time points
%     r = number of observed factors

% Input:   R: N by T , matrix of returns R_t. R is NOT de-meaned. This code  will de-mean it for you.
%          F: T by r,  matrix of observed factors.
%          K: the number of LATENT factors, mannually set
%             Set K=0 if there are NO latent factors


% Output: alpha: N by 1, the estimated alpha
%         se:    N by 1, standard errors
%          t:   alpha/se,   N by 1 vector of t-satistics
 
function [alpha, alpha0, se, se0, t, t0, beta_obs, se_low, eigs]=alpha_mixed_v2(R, F, K)
   
   [N, T]   = size(R);
   
   r        = size(F,2);   
   Rbar     = R - nanmean(R,2)*ones(1,T);
   Fbar     = F - ones(T,1)*nanmean(F,1);
   SS       = cov([Rbar;Fbar']','partialrows');
   
   idmissing= ~(isnan(Rbar));
   for i =1:size(Rbar,1)
        invSF = inv(Fbar(idmissing(i,:)',:)'*Fbar(idmissing(i,:)',:)./sum(idmissing(i,:)));
       beta_obs(i,:) = SS(i,(N+1):(N+r))*invSF;
   end
      
   if K==0  % no latent factors
       
      %  lambda = (beta_obs'*beta_obs)\beta_obs'*nanmean(R,2); % factor risk premia
        
        Miota      = eye(N) - 1/N*ones(N,1)*ones(1,N);
        Mbeta      = eye(N) - beta_obs*inv(beta_obs'*beta_obs)*beta_obs';
        lambda     = (beta_obs'*Miota*beta_obs)\(beta_obs'*Miota*nanmean(R,2));
        alpha0     = (ones(N,1)'*Mbeta*ones(N,1))\(ones(N,1)'*Mbeta*nanmean(R,2));
   
        alpha      = nanmean(R,2)-beta_obs*lambda;
   
     % standard errors
   
        Sf         = F'*(eye(T)-ones(T,T)/T)*F/T;
        U_est      = Rbar-beta_obs*Fbar'; % N by T
        ml         = ones(N,1)*(ones(1,T)- lambda'*inv(Sf)*Fbar');   % N by T
        bl         = (U_est.^2).*(ml.^2); % N by T
        sigma12    = nanmean(bl,2);  % N by 1
  
        D_beta  = beta_obs'* Miota* beta_obs;  
    
        sigma22 = diag((beta_obs*inv(D_beta)*beta_obs')* ((alpha -mean(alpha))'*(alpha -mean(alpha)))) ;  % N by 1
   
        % outputs
       
        %se_high     = sqrt(sigma12/T);
        se_low = sqrt(1/T*diag((eye(N) - (beta_obs*inv(beta_obs'*beta_obs)*beta_obs'))*U_est*U_est'/T* (eye(N) - (beta_obs*inv(beta_obs'*beta_obs)*beta_obs'))*(1 +lambda'*inv(Sf)*lambda))); 
        se0    = sqrt(inv((1 - mean(beta_obs,1)*inv(beta_obs'*beta_obs/N)*mean(beta_obs,1)'))*(alpha -mean(alpha))'*(alpha -mean(alpha)))/N; 
        t0     = alpha0./se0   ;    
 
        eigs=NaN;
          
        
   else % K> 0. Exists latent factors
       
       Z         = Rbar-beta_obs*Fbar';
       Sam_cov   = cov(Z','partialrows');%Z*Z'/T;%demeanZ*demeanZ'/T;
       %[u1,v1]   = eigs(Sam_cov/N,K);
        Sam_cov(isnan(Sam_cov))=0;
       
       [tempV,tempD]         =      eig(Sam_cov/N);  % n < T? 
       [tempeig,tempidx]     =      sort(real(diag(tempD)),'descend');
       eigvec                =      tempV(:,tempidx); 
       u1                    =      eigvec(:,1:K);
       
       eigs=tempeig;
       
       beta_pca  = u1*sqrt(N);  % N by K
       beta_est  = [beta_obs,beta_pca ]; 
      
       Miota      = eye(N) - 1/N*ones(N,1)*ones(1,N);
       Mbeta      = eye(N) - beta_est*inv(beta_est'*beta_est)*beta_est';
       lambda     = (beta_est'*Miota*beta_est)\(beta_est'*Miota*nanmean(R,2));
       alpha0     = (ones(N,1)'*Mbeta*ones(N,1))\(ones(N,1)'*Mbeta*nanmean(R,2));
   

       alpha     = nanmean(R,2)-beta_est*lambda;
       
   
   %  standard error of alpha
   nanidx           = isnan(Z);
   Ztemp            = Z; 
   Ztemp(nanidx)    = 0;  
   factor_pca       = Ztemp'*beta_pca./repmat(N-sum(nanidx,1)',1,K); % T by K  
 %  factor_pca       = Z'*beta_pca/N;
   U_pca            = Z- beta_pca*factor_pca'  ; % N by T
   factor_demeaned  = [Fbar,  factor_pca ]; % T by (r+K) 
   Sigma_factor     = factor_demeaned'*factor_demeaned/T;
   ml               = ones(N,1)*(ones(1,T)- lambda'*inv(Sigma_factor)*factor_demeaned')   ; % N by T
   bl               = (U_pca.^2).*(ml.^2); % N by T
   sigma12          = nanmean(bl,2);  % N by 1
  % D_beta           = beta_est'*beta_est/N;  
  
  % sigma22          = diag(beta_est*inv(D_beta)*beta_est' )* alpha'*alpha/N  ;  % N by 1
   D_beta           = beta_est'*Miota*beta_est;  
   sigma22          = diag((beta_est*inv(D_beta)*beta_est')* ((alpha -mean(alpha))'*(alpha -mean(alpha)))) ;  % N by 1

    se0    = sqrt(inv((1 - mean(beta_est,1)*inv(beta_est'*beta_est/N)*mean(beta_est,1)'))*(alpha -mean(alpha))'*(alpha -mean(alpha)))/N; 
        t0     = alpha0./se0   ;    
 
        se_low = nan;
  % Output: 
   
   end % K
   
        se     = sqrt(sigma12./( T - sum(isnan(R),2))  +  sigma22/N );  % N by 1
        t      = alpha./se   ; % t statistics, N by 1
        
       
   
 
  
       
   
   