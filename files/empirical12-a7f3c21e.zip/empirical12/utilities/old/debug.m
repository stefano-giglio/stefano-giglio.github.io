
[testI1,testI2, testdf, alphadf] =avg_alpha_test(al(use_in_estimation)', be(use_in_estimation,:), select_fdr(use_in_estimation)', select_fdr_onlylatent(use_in_estimation)');