
% Dec 9, 2019
% naive bootstrap + time series only , no CS, ignore latent factors
% allow missing data

% Input:   
%          R: N by T of returns, may subject to missing.  
%          Fo: K by T obser factors
%          B: the number of bootstrap replications. 
%          tau: 0.05

% Output:  
%     p : N by 1 of  p values based on bootstrap 
%     test:  N by 1 of testing decisions
%      alpha_boot: N by B of boostrap estimated alpha
%      alpha:   original alpha estimate, N by 1



function [test, alpha_boot , alpha,p,testL,testHL,testH]=naive_bootstrap_TSonly(R, Fo,  Bootstrapsize,tau)





%% original data estimation

   X           = ~isnan(R);% ~= 0;      
   R_obs=R;
   R_obs(isnan(R_obs)) = 0;
   Fo = Fo';
   [N, T]                = size(R_obs);
   
   K=length(Fo(:,1));  
      beta_est= nan(N,K);
        residual= zeros(N,T);
      alpha=nan(N,1);
        
       for i=1:N
           index=find(X(i,:));
           d=sum(X(i,:));
           M_xi= eye(d) -ones(d,d)/d;
           factor=Fo(:,index);
           Mf=eye(d)- factor'/(factor*factor')*factor;
           beta_est(i,:)= R_obs(i,index)*M_xi*factor'/(factor*M_xi*factor');
           alpha(i)=R_obs(i,index)*Mf*ones( d,1)/(ones(1,d)*Mf*ones( d,1));
           residual(i,index)= R_obs(i,index)-alpha(i)*ones(1,d)- beta_est(i,:)*factor;
       end % i
       
       
      

  alpha_boot = nan(N,  Bootstrapsize);
 
  for b=1: Bootstrapsize
       
       %% generate wild bootstrap data
       
       resample_index = randsample(T,T,1);  % simple random sample with replacement from 1:T , of size T
       U_boot         = residual(:,resample_index); 
       F_boot         = Fo(:,resample_index);
       X_boot         =X(:,resample_index);
       R_boot         = (beta_est*F_boot+ U_boot).*X_boot ; % bootstrap return 
       
       
       
       %% OLS estimate 
    %   beta_boot= nan(N,K);
       for i=1:N
           index=find(X_boot(i,:));
            d=sum(X_boot(i,:));
           M_xi= eye(d) -ones(d,d)/d;
           factor=F_boot(:,index);
           Mf=eye(d)- factor'/(factor*factor')*factor;
          % beta_boot(i,:)= R_boot(i,index)*M_xi*factor'/(factor*M_xi*factor');
            alpha_boot(i,b)=R_boot(i,index)*Mf*ones( d,1)/(ones(1,d)*Mf*ones( d,1));
       end % i
       
        
   end  %  Bootstrapsize: bootstrap replications 
   
   %%  BH test
   
         test    = zeros(N,1); 
         testL    = zeros(N,1); 
         index   = [1:N]';
        
         p       =  (1 + sum(alpha_boot > repmat(alpha,1,Bootstrapsize),2))/(Bootstrapsize + 1); %1-normcdf(new_t); % p-value
         p_sort  = sort(p, 'ascend'); 
         
        
         k_hat   = max((p_sort<=[1:N]'*tau/N).*[1:N]');
        
         if k_hat>0  % there are reject
            
            rejec_index        = index(p<=p_sort(k_hat));         
            test(rejec_index)  = ones(length(rejec_index),1);
        
         end
         
         
         alive      =  X(:,T)==1;
         screening_index= index(alive);
         p_sort_screen  = sort(p(screening_index), 'ascend'); 
         N_screen=length(p_sort_screen);
         
         k_hat_screen   = max((p_sort_screen<=[1:N_screen]'*tau/N_screen).*[1:N_screen]');
        
         if k_hat_screen>0  % there are reject
            b1= p_sort_screen(k_hat_screen);
            rejec_index_screen        = index((p<= b1) & alive);         
            testL(rejec_index_screen)  = ones(length(rejec_index_screen),1);
        
         end

   %% alpha screening & alive
         
       
         testHL    = zeros(N,1); 
         a1=  1-normcdf(-sqrt(log(log(N))));
         screening_index= index((p<=a1) & alive); % outside of set are all accepted . do BH only on this set
  
         p_sort_screen  = sort(p(screening_index), 'ascend'); 
         N_screen=length(p_sort_screen);
        
         k_hat_screen   = max((p_sort_screen<=[1:N_screen]'*tau/N_screen).*[1:N_screen]');
        
         if k_hat_screen>0  % there are reject
            b1= p_sort_screen(k_hat_screen);
            rejec_index_screen        = index((p<= min(a1,b1)) & alive);         
            testHL(rejec_index_screen)  = ones(length(rejec_index_screen),1);
        
         end
         
         
          %% alpha screening 
         
       
         testH    = zeros(N,1); 
         a1=  1-normcdf(-sqrt(log(log(N))));
         screening_index= index((p<=a1)); % outside of set are all accepted . do BH only on this set
  
         p_sort_screen  = sort(p(screening_index), 'ascend'); 
         N_screen=length(p_sort_screen);
        
         k_hat_screen   = max((p_sort_screen<=[1:N_screen]'*tau/N_screen).*[1:N_screen]');
        
         if k_hat_screen>0  % there are reject
            b1= p_sort_screen(k_hat_screen);
            rejec_index_screen        = index((p<= min(a1,b1)));         
            testH(rejec_index_screen)  = ones(length(rejec_index_screen),1);
        
         end