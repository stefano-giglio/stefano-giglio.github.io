function [raweigs,eigs] = findeigs(K,R,F)



   B        =  5000;
   [N, T]   =  size(R);
   r        =  size(F,2);
   KK       =  K+r;
   
   Rbar     =  R - repmat(nanmean(R,2),1,T);% 
   Rbar(isnan(R)) = 0;
   
   [U,S,V]  =  svd(Rbar/sqrt(N)/sqrt(T),'econ');
   vhat     =  T^0.5  * V(:,1:KK)';
   betahat  =  T^(-1) * Rbar * vhat';
   Ubar     =  Rbar - betahat*vhat;
   Sigma_uhat = ((Ubar*Ubar')/T);
   
   
   raweigs = diag(S^2);

  
   [~,~,  ~, ~, ~,~,~,~,~, ~, ~, eigs]   = indi_avar_missing_new(R, F, K, diag(Sigma_uhat),   0.05);
 