% This code estimates bootstrap  alphas when there are  mixed factors and missing data. 

% Model:  R_t= alpha+ beta*gamma + beta1 * g_t(observed) +  beta2 * g_t(latent) + u_t  
%         
% 
 

 

% Let N = number of funds
%     T = number of time points
%     Ko = number of observed factors



% Input:   
%          R_obs: N by T of returns, may subject to missing.  
%          Fo: K by T obser factors
%          Bootstrapsize: the number of bootstrap replications. 
%           tau:  0.05, FDR size
%          storey: a tuning for his FDR control  
%               try: storey = 0.4, or 0.6, or 0.8 , Bajgrowicz and Scaillet (2012) tried 0.6
%                    stoery=0 : the original B-H algorithm
%          grid= set of candidate p value threhold.
%         e.g., set grid =[0.01,0.02, 0.05, 0.1, 0.15, 0.2,0.35, 0.45];


% Output:  
%     p : N by 1 of  p values based on bootstrap 
%     test:  N by 1 of testing decisions
%      alpha_boot: N by B of boostrap estimated alpha
%      alpha:   original alpha estimate, N by 1






function [test, alpha_boot , alpha,p]=barras(R_obs, Fo,   Bootstrapsize,tau, storey,grid)


%% original data estimation

   X           = ~isnan(R_obs);% ~= 0; 
   %          X: N by T of missing indicators. X=1 means obser, X=0 means      missing
   R_obs(isnan(R_obs)) = 0;
   % the input Fo should be Ko by T
   
   Fo =Fo';
  
   [N, T]                = size(R_obs);
      K=length(Fo(:,1));  
      beta_est= nan(N,K);
        residual= zeros(N,T);
      alpha=nan(N,1);
        
       for i=1:N
           index=find(X(i,:));
           d=sum(X(i,:));
           M_xi= eye(d) -ones(d,d)/d;
           factor=Fo(:,index);
           Mf=eye(d)- factor'/(factor*factor')*factor;
           beta_est(i,:)= R_obs(i,index)*M_xi*factor'/(factor*M_xi*factor');
           alpha(i)=R_obs(i,index)*Mf*ones( d,1)/(ones(1,d)*Mf*ones( d,1));
           residual(i,index)= R_obs(i,index)-alpha(i)*ones(1,d)- beta_est(i,:)*factor;
       end % i
       
       
      

  alpha_boot = nan(N,  Bootstrapsize);
 
  parfor b=1: Bootstrapsize
       
       %% generate wild bootstrap data
       
       resample_index = randsample(T,T,1);  % simple random sample with replacement from 1:T , of size T
       U_boot         = residual(:,resample_index); 
       F_boot         = Fo(:,resample_index);
       X_boot         =X(:,resample_index);
       R_boot         = (  beta_est*F_boot+ U_boot).*X_boot ; % bootstrap return 
       
       
       
       %% OLS estimate 
    %   beta_boot= nan(N,K);
       for i=1:N
           index=find(X_boot(i,:));
            d=sum(X_boot(i,:));
           M_xi= eye(d) -ones(d,d)/d;
           factor=F_boot(:,index);
           Mf=eye(d)- factor'/(factor*factor')*factor;
          % beta_boot(i,:)= R_boot(i,index)*M_xi*factor'/(factor*M_xi*factor');
            alpha_boot(i,b)=R_boot(i,index)*Mf*ones( d,1)/(ones(1,d)*Mf*ones( d,1));
       end % i
       
        
   end  %  Bootstrapsize: bootstrap replications 
   
   
%{
 
% %% original data estimation
% 
%      R_obs                 = R.*X;
   [N, T]                = size(R_obs);
    aveR_ind             = sum(R_obs,2)./sum(X,2); 
     Ko          = length(Fo(:,1)); % number of obser factors
     
  
      notmissing_common=(sum(X,1)==N); % 1 by T, time indices at which all funds are observable
             l_common=sum(notmissing_common);
             M_common = eye(l_common) -ones(l_common,l_common)/l_common;
             aveR_common           = mean(R_obs(:,notmissing_common),2); %  N by 1; %  time series averages of returns , ave at commonly observed times
             R_obs_common=R_obs(:, notmissing_common); % at commonly observed times 
             Fo_obs=Fo(:, notmissing_common); % at commonly observed times
             betao_est= R_obs_common*M_common* Fo_obs'/(Fo_obs*M_common*Fo_obs'   ); 
               Vo_common =  mean(Fo_obs,2); % Ko by 1, obs factors averaged over commonly observed times
                Rbar     =  R_obs - ( aveR_common  *ones(1,T)).*X; %R-mean(R,2)*ones(1,T); % N by T with missing
                
             
                 % omit latent factors
                      beta_est= betao_est;
                       factor_est=Fo-Vo_common*ones(1,T);
        
                       
     
 
     M_N= eye(N) - ones(N,N)/N;
     Pbeta= (beta_est'*M_N*beta_est)\beta_est'*M_N;
     lambda_est= Pbeta*aveR_ind  ;   % factor risk premia
       alpha_initial =  aveR_ind  - beta_est*lambda_est; % needs to be debiased
         alpha         =    alpha_initial;
          residual = (Rbar - beta_est*factor_est).*X; % N by T, with missing
           
       
      
         
      
          
          %% bootstrap 
          
  alpha_boot = nan(N, Bootstrapsize);
  
   notmissing_common=nan(1,T);
   
  for b=1:Bootstrapsize
      
       
       %% generate wild bootstrap data
       
       resample_index = randsample(T,T,1);  % simple random sample with replacement from 1:T , of size T
       
        U_boot         = residual(:,resample_index); 
       F_boot         = factor_est(:,resample_index);
       X_boot         =X(:,resample_index);
       R_boot         = (beta_est*lambda_est*ones(1,T) + beta_est*F_boot+ U_boot).*X_boot ; % bootstrap return 
        
       
       %% OLS  for betao on common time
       beta_boot= nan(N,Ko);
        notmissing_common=(sum(X_boot ,1)==N); % 1 by T, time indices at which all funds are observable
             aveR_common_boot           = mean(R_boot(:,notmissing_common),2); %  N by 1; %  time series averages of returns , ave at commonly observed times
             R_obs_common_boot=R_boot(:, notmissing_common); % at commonly observed times 
              vo=  F_boot(1:Ko,:); % Ko by T
      
              
             Fo_obs_boot=vo(:, notmissing_common); % at commonly observed times           
             l_common=sum(notmissing_common);
             M_common = eye(l_common) -ones(l_common,l_common)/l_common;
             betao_boot= R_obs_common_boot*M_common* Fo_obs_boot'/(Fo_obs_boot*M_common*Fo_obs_boot'   ); 

                     beta_boot=betao_boot;
             
                     
       %%  bootstrap alpha
        aveR_ind_boot= sum(R_boot,2)./sum(X_boot,2);
       Pbeta_boot        =   (beta_boot'*M_N*beta_boot)\beta_boot'*M_N; 
          lambda_boot   =    Pbeta_boot*aveR_ind_boot ; 
         
            alpha1=  aveR_ind_boot -  beta_boot* lambda_boot;
         alpha_boot(:,b)       =    alpha1; 
         
          
                   
        
   end  % Bootstrapsize: bootstrap replications 
     %}
  
     p       =  (1 + sum(alpha_boot > repmat(alpha,1,Bootstrapsize),2))/(Bootstrapsize + 1); %1-normcdf(new_t); % p-value
   
   % Storey's test
     hatN =sum(p>=storey)/(1-storey);
   for i=1:length(grid)
       fdr(i)=hatN*grid(i)/sum(p<grid(i));
   end
   [q,w]=min(abs(fdr-tau));
   
   
     test    = p<grid(w);
       
         