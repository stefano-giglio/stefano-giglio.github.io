function dataharm=harm(masterdates,data)

% First column of data should be dates

dataharm=nan(size(masterdates,1),size(data,2)-1);

[c,ia,ib]=intersect(masterdates,data(:,1));

dataharm(ia,:)=data(ib,2:end);


