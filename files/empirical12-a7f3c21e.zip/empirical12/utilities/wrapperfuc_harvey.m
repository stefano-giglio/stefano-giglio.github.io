function results = wrapperfuc_harvey(K,R,F)

%Input: R  NxT matrix of returns. Missing is NaN.
%       F  Txr matrix of factors. No Missing.
%       K  number of latent factors.

%Output: results.test : our baseline result using observable and latentfactors
%        restlts.testH: same as above, with alpha screening
%        results.alpha_est: same as above, alpha estimates
%        results.se:        same as above, se
%        resutlts.tstats:   same as above, tstats

%        results.testnaive  : our baseline result with omitted factors
%        restlts.testHnaive: same as above, with alpha screening   %USELESS
%        results.alpha_estnaive: same as above, alpha estimates
%        results.senaive:        same as above, se
%        resutlts.tstatsnaive:   same as above, tstats

%        results.testlatent: our baseline result using latent factors only
%        restlts.testHlatent: same as above, with alpha screening
%        results.alpha_estlatent: same as above, alpha estimates
%        results.selatent:        same as above, se
%        resutlts.tstatslatent:   same as above, tstats


%        results.testB      : our bootstrap result using latent factors only
%        results.testB_mix  : our baseline result using observable and latent factors


   B        =  5000;
   [N, T]   =  size(R);
   r        =  size(F,2);
   KK       =  K+r;
   
   Rbar     =  R - repmat(nanmean(R,2),1,T);% 
   Rbar(isnan(R)) = 0;
   
   [U,S,V]  =  svd(Rbar/sqrt(N)/sqrt(T),'econ');
   vhat     =  T^0.5  * V(:,1:KK)';
   betahat  =  T^(-1) * Rbar * vhat';
   Ubar     =  Rbar - betahat*vhat;
   Sigma_uhat = ((Ubar*Ubar')/T);
   
   

%% Estimation 
  % sc  = 2;  %scenario 1 or 2

  
   [results.test,results.testH,  results.se, results.alpha_est, results.p,results.beta,results.factor,results.lambda,results.testHL,~, results.testL,~,results.var1]   = indi_avar_missing_new(R, F, K, diag(Sigma_uhat),   0.05);% =  fdrcontrol_MC(1, K, R, F, 0.05, sc, diag(Sigma_uhat));
      
   results.testHarveyLiu= HarveyandLiu_new( R, F, 0.2, 0.05);
end