
% Dec 19, 2020
% all use individual times, no common times

% Let N = number of funds
%     T = number of time points
%     Ko = number of observed factors

%     if latent factor only, set Fo=0.
%     if obser factor only, set Kl=0.

% Input:   
%          R: N by T of returns, may subject to missing.  
%          Fo: Ko by T, matrix of observed factors
%          Kl: number of latent factors
%         sigmau: N by 1
%          tau: significance level

% Output:  
%     p : N by 1 of  p values based on bootstrap 
%     test:  N by 1 of testing decisions, 1= reject
%      se: N by 1 standard error
%      alpha:   alpha estimate, N by 1


function [testB, testBH, se, alpha, p, beta_est, factor_est,  lambda_est, testBHL,R2, testBL, eigs,var1]=indi_avar_missing_new(R_obs, Fo, Kl,  sigmau,  tau )


%% original data estimation
%          X: N by T of missing indicators. X=1 means obser, X=0 means       missing

     X           = ~isnan(R_obs);% ~= 0; 
   R_obs(isnan(R_obs)) = 0;
   [N, T]                = size(R_obs);
    aveR_ind             = sum(R_obs,2)./sum(X,2); 
    Rbar     =  R_obs -  aveR_ind  *ones(1,T);
    Fo =Fo';
     if ~isempty(Fo)
        Ko          = length(Fo(:,1)); % number of obser factors
    else % no obser factors
        Ko=0;
     end
    
     K=Ko+Kl;
     
     if Kl==0 
         ff=1; % obser factor only
     end
     if Ko==0
         ff=2;  % latent only
     end
     if Ko*Kl>0
         ff=3; % mix
     end
     
      
     
     switch ff
         
         case 1 % obser factor only
             betao_est=nan(N,Ko);
             Vo=Fo-mean(Fo,2)*ones(1,T);
            for i=1:N
               index=find(X(i,:));
              d=sum(X(i,:));
              M_xi= eye(d) -ones(d,d)/d;
              factor=Fo(:,index);
              betao_est(i,:)= R_obs(i,index)*M_xi*factor'/(factor*M_xi*factor');  
            end % i
            beta_est=betao_est;
            factor_est= Vo;
         case 2 % latent only
              Z=X.*  Rbar ; % OLS residual, with individual missing
               [betal_est,F_l_est] = matrix_completion(Z,X, Kl, sigmau);
               beta_est = betal_est; % Ko=0
               factor_est = F_l_est ; % K by T
         case 3 % mix
             betao_est=nan(N,Ko);
             Vo=Fo-mean(Fo,2)*ones(1,T);
             Z=zeros(N,T);
            for i=1:N
               index=find(X(i,:));
              d=sum(X(i,:));
              M_xi= eye(d) -ones(d,d)/d;
              factor=Fo(:,index);
              betao_est(i,:)= R_obs(i,index)*M_xi*factor'/(factor*M_xi*factor');  
              Z(i,index)=  (R_obs(i,index)-betao_est(i,:)*factor)*M_xi;
            end % i
            
           % Z=X.*(  Rbar  -betao_est*Vo); % OLS residual, with individual missing
            [betal_est,F_l_est] = matrix_completion(Z,X, Kl, sigmau);
            beta_est=[betao_est,betal_est];
            factor_est=[Vo;F_l_est]; % K by T
     end % switch
     residual = (Rbar - beta_est*factor_est).*X; % N by T, with missing
       
     [~,S,~]  =  svd(residual/sqrt(N)/sqrt(T),'econ'); 
     eigs = diag(S^2);      
  
     M_N= eye(N) - ones(N,N)/N;
     Pbeta= (beta_est'*M_N*beta_est)\beta_est'*M_N;
     lambda_est= Pbeta*aveR_ind  ;   % factor risk premia
     
     alpha_initial=aveR_ind  - beta_est*lambda_est ;
     
     %% bias 
      B   =    eye(N)-beta_est*Pbeta; % needed for debias alpha
       g    =    nan(N,1);              % needed for debias alpha
 
        for i=1:N
                 g(i)                =   beta_est(i,:)* mean(factor_est(:,X(i,:)==1),2);
        end
        bias1=B*g;
          
         % for bias2
         
               bias2=zeros(N,1);
       if ff==3 % mixed case
           So=Vo*Vo'/T;
           Slo=F_l_est*Vo'/T;
           Ho=Slo/So;
          for i=1:N
              index=find(X(i,:));
              d=sum(X(i,:));
              Soi= Vo(:,index)*Vo(:,index)'/d;
              Sloi=F_l_est(:,index)*Vo(:,index)'/d;
              Hoi= Sloi/Soi;
              bias2(i)= betal_est(i,:)*(Hoi-Ho)*lambda_est(1:Ko); 
           end % i
       end % ff=3
        
       
       
         alpha         =  alpha_initial   - bias1+bias2 ;
       
      
        
          
          
             
             
             %%
             %  variance_alpha =0 ;
            % alpha =  alpha_initial   - bias1+bias2+  beta_est* Pbeta * alphatrue;
            
            
          %% se 
            
             variance_alpha =  diag( beta_est/(beta_est'* M_N*beta_est) * beta_est'*var(alpha_initial))  ;
           
            
            
            S_f=factor_est*factor_est'/T;
%             var1=nan(N,1);
%           %  mm=norm(ones(1,T)-lambda_est'/S_f* factor_est)^2/T; % method 3
%            for i=1:N
%                 index=find(X(i,:));
%                 d=sum(X(i,:));
%                 %  m=residual(i,index) .*(1-lambda_est'/S_f*factor_est(:,index) ); % method 1
%                  % var1(i)=norm(m)^2/d^2; % method 1
%                    su=residual(i,index)*residual(i,index)'/d; % method 2,3
%                  var1(i)= su*norm(1-lambda_est'/S_f* factor_est(:,index))^2/d^2; % metthod 2
%                 %var1(i)= su * mm/d; % method 3
% 
%            end
%            
              var1=nan(N,1);
          %  mm=norm(ones(1,T)-lambda_est'/S_f* factor_est)^2/T; % method 3
           for i=1:N
                index=find(X(i,:));
                d=sum(X(i,:));
                  m=residual(i,index) .*(1-lambda_est'/S_f*factor_est(:,index) ); % method 1
                  var1(i)=norm(m)^2/d^2; % method 1
                 %  su=residual(i,index)*residual(i,index)'/d; % method 2,3
                % var1(i)= su*norm(1-lambda_est'/S_f* factor_est(:,index))^2/d^2; % metthod 2
                %var1(i)= su * mm/d; % method 3

           end
             se=sqrt(var1+variance_alpha);
      
         p=1-normcdf(alpha./se);
         
   
      %% B-H, B-H & ALIVE
        alive      =  X(:,T)==1;   
      
      
         testB    = zeros(N,1); 
         index   = [1:N]';
 
  
      
  
         p_sort  = sort(p, 'ascend'); 
        
         k_hat   = max((p_sort<=[1:N]'*tau/N).*[1:N]');
        
         if k_hat>0  % there are reject
            
            rejec_index        = index(p<=p_sort(k_hat));         
            testB(rejec_index)  = ones(length(rejec_index),1);
        
         end
         
         testBL    = zeros(N,1); 
         screening_index= index(alive);       
         p_sort_screen  = sort(p(screening_index), 'ascend'); 
         N_screen=length(p_sort_screen);        
         k_hat_screen   = max((p_sort_screen<=[1:N_screen]'*tau/N_screen).*[1:N_screen]');
        
         if k_hat_screen>0  % there are reject
            b1= p_sort_screen(k_hat_screen);
            rejec_index_screen        = index((p<= (b1)) & alive);         
            testBL(rejec_index_screen)  = ones(length(rejec_index_screen),1);
        
         end
         
         
             %% alpha screening
         
         
         testBH    = zeros(N,1); 
         a1=  1-normcdf(-sqrt(log(log(N))));
         screening_index= index(p<=a1); % outside of set are all accepted . do BH only on this set
  
       
  
         p_sort_screen  = sort(p(screening_index), 'ascend'); 
         N_screen=length(p_sort_screen);
        
         k_hat_screen   = max((p_sort_screen<=[1:N_screen]'*tau/N_screen).*[1:N_screen]');
        
         if k_hat_screen>0  % there are reject
            b1= p_sort_screen(k_hat_screen);
            rejec_index_screen        = index(p<= min(a1,b1));         
            testBH(rejec_index_screen)  = ones(length(rejec_index_screen),1);
        
         end
   
         
         
             %% alpha screening & alive
         
       
         testBHL    = zeros(N,1); 
         a1=  1-normcdf(-sqrt(log(log(N))));
         screening_index= index((p<=a1) & alive); % outside of set are all accepted . do BH only on this set
  
       
  
         p_sort_screen  = sort(p(screening_index), 'ascend'); 
         N_screen=length(p_sort_screen);
        
         k_hat_screen   = max((p_sort_screen<=[1:N_screen]'*tau/N_screen).*[1:N_screen]');
        
         if k_hat_screen>0  % there are reject
            b1= p_sort_screen(k_hat_screen);
            rejec_index_screen        = index((p<= min(a1,b1)) & alive);         
            testBHL(rejec_index_screen)  = ones(length(rejec_index_screen),1);
        
         end
   
         
alpha0 = mean(alpha_initial);
rr = mean(aveR_ind); 
SSR= norm( alpha0 + beta_est*lambda_est - rr)^2;
SST= norm(aveR_ind- rr)^2;
R2= SSR/SST;
   