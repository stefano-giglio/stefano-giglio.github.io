
% ----------------------------------------------------------------------------
% ----------------------------------------------------------------------------

close all


clear
clc
load data/cleaneddata.mat
addpath utilities

%Picture of eigenvalues
%------------------------------------------------


for usemodel=1:2
    
    clearvars -except usemodel EIGS
    
    if usemodel==1 % Only market
        load data/cleaneddata.mat
        nlatent=3;
        minmonths=36;
        factors=[factor_ret.mktrf];
        wind=12*10; % Lookback window for estimation
        firstyear=2004;
        lastyear=2017;
        computeym=(firstyear:lastyear)'*100+12;
        NMONTHS=12;
        LAG=0;
        obser=1;
    elseif usemodel==2 % FH7
        load data/cleaneddata.mat
        nlatent=3;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2004;
        lastyear=2017;
        computeym=(firstyear:lastyear)'*100+12;
        NMONTHS=12;
        LAG=0;
        obser=1;
    end
    
    
    nfactors=size(factors,2)+nlatent;

    % Cut periods with missing fac tors
    f=find(isnan(sum(factors,2)));
    ret(f,:)=[];
    aum(f,:)=[];
    factors(f,:)=[];
    ymlist(f)=[];

    alive=sum(~isnan(ret))>=minmonths;
    
    % Train
    ret_train=ret(:,alive);
    fac=factors;
    
    % Remove periods with too few funds
    id = sum(isnan(ret_train)');
    fac=fac(find(size(ret_train,2) - id > nfactors,1):end,:);
    ret_train   =  ret_train(find(size(ret_train,2) - id > nfactors,1):end,:);
    
    % Run estimation
    [raweigs,eigs] = findeigs(0,ret_train',fac);
    [raweigs,eigsmixed] = findeigs(nlatent,ret_train',fac);
    
    EIGS(usemodel+1,:)=eigs(1:15)';
end

EIGS(1,:)=raweigs(1:15)';
EIGS(4,:)=eigsmixed(1:15)';
figure
plot(EIGS(1,:)','*-','LineWidth',2)
hold on;
plot(EIGS(2,:)','+-','LineWidth',2)
hold on;
plot(EIGS(3,:)','o-','LineWidth',2)
legend('Latent','Market','FH7')
set(gca,'FontSize',18)
save2pdf('output/eigs.pdf');
close
 

% In-sample tables

% Add Harvey
clear
clc

load output/insampleres_harvey
alpha_harvey=alpha_results;
t_harvey=t_results;
nselect_harvey=nselect;
aums_harvey=aums;

load output/insampleres.mat

disp('1 FDR 2 FDR no screening 3 Barras 4 Onlylatent FDR 5 NaiveFDR 6 NaiveFDR_noscreening 7 NaiveStand 8 NaiveOth 9 Avar 10 Harvey');
TABLE=[alpha_results;t_results;nan(1,9);nselect];
TABLE=[TABLE [alpha_harvey;t_harvey; NaN; nselect_harvey]];



%Test of differences, in sample results

al=nan(size(use_in_estimation));
be=nan(size(use_in_estimation,2),size(results.beta,2));
al(use_in_estimation)=results.alpha_est;
be(use_in_estimation,:)=results.beta;

for j=2:10
    if j==2
        sel=select_fdr_noscreening(use_in_estimation)';
    elseif j==3
        sel=select_barras(use_in_estimation)';
    elseif j==4
        sel=select_fdr_onlylatent(use_in_estimation)';
    elseif j==5
        sel=select_fdr_naive(use_in_estimation)';
    elseif j==6
        sel=select_fdr_naive_noscreening(use_in_estimation)';
    elseif j==7
        sel=select_standard_naive(use_in_estimation)';
    elseif j==8
        sel=select_others_naive(use_in_estimation)';
    elseif j==9
        sel=select_fdr_avar(use_in_estimation)';
    else
        sel=select_harvey(use_in_estimation)';
    end    

    [testI1,testI2, testdf, alphaI1, alphaI2, alphadf] =avg_alpha_test(al(use_in_estimation)', be(use_in_estimation,:), select_fdr(use_in_estimation)', sel,results.var1);
    TABLE(3,1)=2*(1-normcdf(abs(testI1)));
    TABLE(3,j)=2*(1-normcdf(abs(testI2)));
    TABLE(5,j)=2*(1-normcdf(abs(testdf)));
end
TABLE(5,1)=NaN;


    


clear
clc

for usemodel=1:13
    
    load(['output/harveyresnew_' num2str(usemodel)]);
    temp_harvey=alphas_monthly;
    table_alphas(usemodel,10)=mean(alphas_monthly);
    temp=sqrt(size(alphas_monthly,1))*mean(alphas_monthly)./std(alphas_monthly);
    table_tstat(usemodel,10)=2*(1-normcdf(abs(temp)));
    table_aum(usemodel,10)=mean(aums/1000000000);
    table_select(usemodel,10)=mean(nselect./nalive);
    
    load(['output/res_' num2str(usemodel)]);
    
    table_alphas(usemodel,1:9)=mean(alphas_monthly);
    temp=sqrt(size(alphas_monthly,1))*mean(alphas_monthly)./std(alphas_monthly);
    table_tstat(usemodel,1:9)=2*(1-normcdf(abs(temp)));
    table_nused(usemodel,1)=mean(nused);
    table_nalive(usemodel,1)=mean(nalive);
    table_aum(usemodel,1:9)=mean(aums/1000000000);
    table_select(usemodel,1:9)=mean(nselect./nalive);
    
    for j=2:9
        temp=(nanmean(alphas_monthly(:,1)-alphas_monthly(:,j))./nanstd(alphas_monthly(:,1)-alphas_monthly(:,j)))*sqrt(size(alphas_monthly,1));
        table_diff(usemodel,j)=2*(1-normcdf(abs(temp)));
    end
    temp=(nanmean(alphas_monthly(:,1)-temp_harvey)./nanstd(alphas_monthly(:,1)-temp_harvey))*sqrt(size(alphas_monthly,1));
    table_diff(usemodel,10)=2*(1-normcdf(abs(temp)));
end
