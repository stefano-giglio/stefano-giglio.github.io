Readme file for Thousands of Alpha Tests

1) In the folder hedge_fund_data, run the python files in the code folder, in the order described by the readme.pdf file

2) In the folder data_orig, run importall.do

3) Run dataprep_tass and dataprep_evestment

4) Then run main, main_harvey_insample and main_harvey_oos

5) Finally, run tables.m



