addpath utilities

clear
load data/cleaneddata.mat
nlatent=3;
minmonths=36;
factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];

nfactors=size(factors,2)+nlatent;

% Cut periods with missing factors
f=find(isnan(sum(factors,2)));
ret(f,:)=[];
aum(f,:)=[];
factors(f,:)=[];
ymlist(f)=[];
    
use_in_estimation=sum(~isnan(ret))>=minmonths;
    
% Train
ret_train=ret(:,use_in_estimation);
fac=factors;

% Remove periods with too few funds
id = sum(isnan(ret_train)');
ymlist=ymlist(find(size(ret_train,2) - id > nfactors,1):end);
fac=fac(find(size(ret_train,2) - id > nfactors,1):end,:);
ret_train   =  ret_train(find(size(ret_train,2) - id > nfactors,1):end,:);


% Run estimation
results = wrapperfuc_harvey(nlatent,ret_train',fac);

% Compute selected funds
select_harvey=false(size(use_in_estimation));
        
select_harvey(find(use_in_estimation))=results.testHarveyLiu; 

nused=sum(use_in_estimation);
nselect=[sum(select_harvey)];

alphas=results.alpha_est;

alpha_harvey=nan(size(use_in_estimation));

alpha_harvey(use_in_estimation)=alphas;

alpha_harvey(~select_harvey)=NaN;

p_harvey=nan(size(use_in_estimation));


p_harvey(use_in_estimation)=results.p;


p_harvey(~select_harvey)=NaN;


t_harvey=nan(size(use_in_estimation));

t_harvey(use_in_estimation)=results.alpha_est./results.se;


t_harvey(~select_harvey)=NaN;


w=nanmean(aum);
                  
aums=[nansum(w(select_harvey))];
                 
alpha_results=[nanmean(alpha_harvey)];

t_results=[nanmean(t_harvey)];

p_results=[nanmean(p_harvey)];

% Results:
% alpha_results, t_results, aum, nselect
alpha_results=alpha_results*10000; % in bp per month
nselect=nselect/sum(use_in_estimation)
aums=aums/1000000000; % in bn
    
save output/insampleres_harvey.mat
    