addpath utilities

% Recursive (OOS) analysis
% ------------------------------------------------

clear
clc

for usemodel=1:13
    
    clearvars -except usemodel
    
    valueweight=1;
    
    if usemodel==1 % Baseline (yearly rebalancing)
        load data/cleaneddata.mat
        nlatent=3;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2004;
        lastyear=2017;
        computeym=(firstyear:lastyear)'*100+12;
        NMONTHS=12;
        LAG=0;
    elseif usemodel==2 % 1 month lag
        load data/cleaneddata.mat
        nlatent=3;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2004;
        lastyear=2017;
        computeym=(firstyear:lastyear)'*100+12;
        NMONTHS=12;
        LAG=1;
    elseif usemodel==3 % 3 month lag
        load data/cleaneddata.mat
        nlatent=3;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2004;
        lastyear=2017;
        computeym=(firstyear:lastyear)'*100+12;
        NMONTHS=12;
        LAG=1;
    elseif usemodel==4 % Require 5 years
        load data/cleaneddata.mat
        nlatent=3;
        minmonths=60;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2004;
        lastyear=2017;
        computeym=(firstyear:lastyear)'*100+12;
        NMONTHS=12;
        LAG=1;
     elseif usemodel==5 % Monthly
        load data/cleaneddata.mat
        nlatent=3;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2004;
        lastyear=2018;
        computeym=[];
        for j=firstyear:lastyear
            computeym=[computeym;j*100+(1:12)'];
        end
        ff=find(computeym>201811);
        computeym(ff)=[];
        NMONTHS=1;
        LAG=0;
    elseif usemodel==6 % Monthly, 1 lag
        load data/cleaneddata.mat
        nlatent=3;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2004;
        lastyear=2018;
        computeym=[];
        for j=firstyear:lastyear
            computeym=[computeym;j*100+(1:12)'];
        end
        ff=find(computeym>201810);
        computeym(ff)=[];
        NMONTHS=1;
        LAG=1;
    elseif usemodel==7 % Monthly, 3 lag
        load data/cleaneddata.mat
        nlatent=3;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2004;
        lastyear=2018;
        computeym=[];
        for j=firstyear:lastyear
            computeym=[computeym;j*100+(1:12)'];
        end
        ff=find(computeym>201808);
        computeym(ff)=[];
        NMONTHS=1;
        LAG=3;
    elseif usemodel==8 % Use 5 latent factors
        load data/cleaneddata.mat
        nlatent=5;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2004;
        lastyear=2017;
        computeym=(firstyear:lastyear)'*100+12;
        NMONTHS=12;
        LAG=0;
   
    elseif usemodel==9 % Benchmark FF4 plus options
        load data/cleaneddata.mat
        nlatent=3;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.hml factor_ret.mom factor_ret.otmcall factor_ret.otmput];
        wind=12*10; % Lookback window for estimation
        firstyear=2006;
        lastyear=2015;
        computeym=(firstyear:lastyear)'*100+12;
        NMONTHS=12;
        LAG=0;
    elseif usemodel==10 % Evestment
        load data/cleaneddata_evestment.mat
        nlatent=4;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2007;
        lastyear=2016;
        computeym=(firstyear:lastyear)'*100+12;
        NMONTHS=12;
        LAG=0;
    elseif usemodel==11 % Evestment Monthly
        load data/cleaneddata_evestment.mat
        nlatent=4;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2007;
        lastyear=2016;
        computeym=[];
        for j=firstyear:lastyear
            computeym=[computeym;j*100+(1:12)'];
        end
        NMONTHS=1;
        LAG=0;
    elseif usemodel==12 % Only US
        load data/cleaneddata_us.mat
        nlatent=3;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2004;
        lastyear=2017;
        computeym=(firstyear:lastyear)'*100+12;
        NMONTHS=12;
        LAG=0;
    elseif usemodel==13 % Equal weighted
        load data/cleaneddata.mat
        nlatent=3;
        minmonths=36;
        factors=[factor_ret.mktrf factor_ret.smb factor_ret.bondfactor  factor_ret.csfactor factor_ret.PTFSBD factor_ret.PTFSFX factor_ret.PTFSCOM ];
        wind=12*10; % Lookback window for estimation
        firstyear=2004;
        lastyear=2017;
        computeym=(firstyear:lastyear)'*100+12;
        NMONTHS=12;
        LAG=0;
        valueweight=0;
    end

    
    
    nfactors=size(factors,2)+nlatent;

    % Cut periods with missing factors
    f=find(isnan(sum(factors,2)));
    ret(f,:)=[];
    aum(f,:)=[];
    factors(f,:)=[];
    ymlist(f)=[];

    NRESULTS=1;
    
    tic
    nalive=nan(length(computeym),1);
    nused=nan(length(computeym),1);
    nselect=nan(length(computeym),NRESULTS);
    aums=nan(length(computeym),NRESULTS);
    alphas=nan(length(computeym),NRESULTS);
    alphas_monthly=nan(NMONTHS,NRESULTS,length(computeym));
    for jj=1:length(computeym)

        oos_start=find(ymlist==computeym(jj));
        computeym(jj)

        alive=~isnan(ret(oos_start,:)) & sum(~isnan(ret(oos_start-wind+1:oos_start,:)))>=minmonths;
        
        use_in_estimation=sum(~isnan(ret(oos_start-wind+1:oos_start,:)))>=minmonths;
    
        % Train
        ret_train=ret(oos_start-wind+1:oos_start,use_in_estimation);
        fac=factors(oos_start-wind+1:oos_start,:);

        % Remove periods with too few funds
        id = sum(isnan(ret_train)');
        fac=fac(find(size(ret_train,2) - id > nfactors,1):end,:);
        ret_train   =  ret_train(find(size(ret_train,2) - id > nfactors,1):end,:);

        %save(['snapshots/snapshot_' num2str(computeym(jj)) '.mat'],'ret_train','fac');
        
        % Run estimation
        results = wrapperfuc_harvey(nlatent,ret_train',fac);


        % Compute selected funds
        select_harvey=false(size(use_in_estimation));
        
        select_harvey(find(use_in_estimation))=results.testHarveyLiu; select_harvey=select_harvey & alive;
        
        nalive(jj)=sum(alive);
        nused(jj)=sum(use_in_estimation);
        nselect(jj,:)=[sum(select_harvey)];

        % Compute betas
        betas=nan(size(use_in_estimation,2),size(results.beta,2));
        betas(use_in_estimation,:)=results.beta;
        
        w=aum(oos_start,:);
        
        if valueweight==0
            w(~isnan(w))=1;
        end
                  
        aums(jj,:)=[nansum(w(select_harvey))];
                 
        alpha_oos_monthly=ret(oos_start+1+LAG:oos_start+NMONTHS+LAG,alive)-(betas(alive,:)*results.lambda)';
        
        alpha_oos_harvey_monthly=nan(NMONTHS,size(alive,2));
        
        alpha_oos_harvey_monthly(:,alive)=alpha_oos_monthly;
               
        alpha_oos_harvey_monthly(:,~(select_harvey & alive))=NaN;     
       
        alphas_monthly(:,:,jj)=[nansum(w.*alpha_oos_harvey_monthly,2)/nansum(w.*~isnan(alpha_oos_harvey_monthly(1,:)))];
        
        
    end
    
    toc
    
    splitA = num2cell(alphas_monthly, [1 2]);
    alphas_monthly=vertcat(splitA{:});
    
    alphas_monthly(isnan(alphas_monthly))=0;
    alphas(isnan(alphas))=0;
    aums(isnan(aums))=0;

    disp('alphas')
    12*mean(alphas_monthly)
     
    disp('nalive')
    mean(nalive)
    
    disp('nused')
    mean(nused)

    disp('fraction select')
    mean(nselect./nalive)

    disp('AUM')
    mean(aums/1000000)
    
    save(['output/harveyresnew_' num2str(usemodel)]);
    
end    




    
    