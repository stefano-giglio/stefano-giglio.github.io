"""
export_fastregress.py
=====================

Lightweight, self-contained export of the `fast_regress3` OLS / FE-OLS routine
with cluster-robust (CRV1) variance, plus two helpers for building dummy
variables (`add_dummies`, `add_dummy_cols`).

This module is a slimmed-down extract of the full `fastregress_library.py`
used in the Florida building-permits project. It includes only what is
needed to run `fast_regress3`:

  * `_series_to_codes`, `_is_nested_np`  — factorisation / nesting helpers
  * `_demean_inplace`, `_cluster_score_sum` — numba kernels
  * `fast_regress3` — the regression routine
  * `add_dummies`, `add_dummy_cols` — categorical-variable expansion helpers

Dependencies: polars, numpy, pandas, numba, scipy.

Author of the full library: Stefano Giglio (Yale).
"""

import operator
import re
import gc
from functools import reduce

import numpy as np
import pandas as pd
import polars as pl
import numba
from scipy import stats


# ──────────────────────────────────────────────────────────────────────────
# Shared helpers
# ──────────────────────────────────────────────────────────────────────────

def _series_to_codes(series: pl.Series) -> tuple[np.ndarray, int]:
    """Polars Series → contiguous int codes 0..G-1, plus G.

    Avoids Utf8 round-trip for integer / boolean columns (e.g. clip with 5.8M
    unique int64 values, which `cast(pl.Utf8).cast(pl.Categorical)` formats
    one string per row — the slowest step in the pipeline at full-state
    scale).  Branches by dtype:
      - integer / boolean: take raw values, run np.unique with return_inverse
      - everything else: cast to Categorical, fall back to np.unique
    """
    dtype = series.dtype
    if dtype.is_integer() or dtype == pl.Boolean:
        arr = series.to_numpy()
        if arr.dtype != np.int64:
            arr = arr.astype(np.int64, copy=False)
        _, codes = np.unique(arr, return_inverse=True)
    else:
        codes = series.cast(pl.Categorical).to_physical().to_numpy().astype(np.int64)
        _, codes = np.unique(codes, return_inverse=True)
    return codes.astype(np.intp), int(codes.max()) + 1 if len(codes) else 0


def _is_nested_np(fe_ids_arr: np.ndarray, cluster_ids: np.ndarray) -> bool:
    """Return True iff every FE group maps to exactly one cluster value.

    Pure-numpy implementation: combines (fe, cl) into a single int64 key,
    counts distinct pairs.  Vastly faster than iterating in Python for 66M
    rows.
    """
    if len(fe_ids_arr) == 0:
        return True
    n_cl = int(cluster_ids.max()) + 1
    combined = fe_ids_arr.astype(np.int64) * n_cl + cluster_ids.astype(np.int64)
    n_pairs = len(np.unique(combined))
    n_fe = int(fe_ids_arr.max()) + 1
    return n_pairs == n_fe


# ──────────────────────────────────────────────────────────────────────────
# numba kernels
# ──────────────────────────────────────────────────────────────────────────

@numba.njit(parallel=True, cache=True)
def _demean_inplace(X, y, group_ids, G):
    """Demean X (N x K) and y (N,) by group in a single pass over group_ids."""
    N, K = X.shape
    # Pass 1: accumulate sums and counts
    sums_X = np.zeros((G, K), dtype=np.float64)
    sums_y = np.zeros(G, dtype=np.float64)
    counts = np.zeros(G, dtype=np.float64)
    for i in range(N):
        g = group_ids[i]
        counts[g] += 1.0
        sums_y[g] += y[i]
        for j in range(K):
            sums_X[g, j] += X[i, j]
    # Compute means
    for g in range(G):
        if counts[g] > 0:
            sums_y[g] /= counts[g]
            for j in range(K):
                sums_X[g, j] /= counts[g]
    # Pass 2: subtract means
    for i in numba.prange(N):
        g = group_ids[i]
        y[i] -= sums_y[g]
        for j in range(K):
            X[i, j] -= sums_X[g, j]
    return counts


@numba.njit(parallel=True, cache=True)
def _cluster_score_sum(X, u_hat, cluster_ids, G):
    """Compute summed[g, j] = sum_{i in cluster g} X[i,j] * u[i] in one pass."""
    N, K = X.shape
    summed = np.zeros((G, K), dtype=np.float64)
    for i in range(N):
        g = cluster_ids[i]
        ui = u_hat[i]
        for j in range(K):
            summed[g, j] += X[i, j] * ui
    return summed


# ──────────────────────────────────────────────────────────────────────────
# fast_regress3
# ──────────────────────────────────────────────────────────────────────────

def fast_regress3(
    df: pl.DataFrame,
    y_col: str,
    x_cols: list[str],
    fe_col=None,
    cluster1_col: str | None = None,
    cluster2_col: str | None = None,
) -> dict:
    """
    OLS / FE-OLS with cluster-robust (CRV1) or two-way CRV1 variance.

    Uses fixest-style small-sample correction: FE degrees of freedom are only
    subtracted from dof_resid when the FE are NOT nested within the
    clustering variable(s).  When FE are nested (e.g. `clip` FE clustered at
    `zip`), uses dof_resid = n - k - 1 instead of n - k - G_fe, matching R's
    fixest / pyfixest default (k_fixef='nonnested').

    Parameters
    ----------
    df : pl.DataFrame
    y_col : str
    x_cols : list[str]
    fe_col : None | str | list[str]   # one or more FE columns to absorb
    cluster1_col : None | str         # first clustering variable
    cluster2_col : None | str         # second clustering variable (optional)

    Returns
    -------
    dict with: beta, se, t_stats, vcov, R2_overall, R2_within, RMSE,
    dof_resid, n, k, G_fe, summary_df, ...
    """
    if not isinstance(df, pl.DataFrame):
        raise ValueError("df must be a polars DataFrame")

    # ------------------------------------------------------------------ #
    # 0. Normalise fe_col
    # ------------------------------------------------------------------ #
    if fe_col is None:
        fe_cols = []
    elif isinstance(fe_col, (list, tuple)):
        fe_cols = list(fe_col)
    else:
        fe_cols = [fe_col]

    # ------------------------------------------------------------------ #
    # 1. Drop rows with nulls / NaNs in any required column
    # ------------------------------------------------------------------ #
    required_cols = [y_col] + list(x_cols) + fe_cols
    if cluster1_col:
        required_cols.append(cluster1_col)
    if cluster2_col:
        required_cols.append(cluster2_col)
    seen: set[str] = set()
    required_cols = [c for c in required_cols if not (c in seen or seen.add(c))]

    df = df.filter(reduce(operator.and_, [pl.col(c).is_not_null() for c in required_cols]))
    float_cols = [c for c in required_cols if df.schema[c] in (pl.Float32, pl.Float64)]
    if float_cols:
        df = df.filter(reduce(operator.and_, [pl.col(c).is_not_nan() for c in float_cols]))

    # ------------------------------------------------------------------ #
    # 2. Iterative singleton dropping
    # ------------------------------------------------------------------ #
    n_singletons_dropped = 0

    if fe_cols:
        def _make_fe_ids(frame: pl.DataFrame) -> np.ndarray:
            # Skip Utf8 round-trip for single-column integer/boolean FE.
            if len(fe_cols) == 1:
                series = frame[fe_cols[0]]
                if series.dtype.is_integer() or series.dtype == pl.Boolean:
                    arr = series.to_numpy()
                    if arr.dtype != np.int64:
                        arr = arr.astype(np.int64, copy=False)
                    _, codes = np.unique(arr, return_inverse=True)
                    return codes.astype(np.intp)
                # Non-numeric single-column FE: cast to Categorical to get integer
                # codes, THEN factorize via np.unique to compact 0..G-1.
                arr = series.cast(pl.Categorical).to_physical().to_numpy()
                _, codes = np.unique(arr, return_inverse=True)
                return codes.astype(np.intp)
            # Multi-column FE: hash the struct, factorize the uint64 hash directly.
            hashed = frame.select(
                pl.struct(fe_cols).hash().alias("_fe_hash")
            )["_fe_hash"].to_numpy()
            _, codes = np.unique(hashed, return_inverse=True)
            return codes.astype(np.intp)

        while True:
            fe_ids = _make_fe_ids(df)
            counts = np.bincount(fe_ids)
            keep_mask = counts[fe_ids] > 1
            n_dropped_this_pass = int((~keep_mask).sum())
            if n_dropped_this_pass == 0:
                break
            n_singletons_dropped += n_dropped_this_pass
            df = df.filter(pl.Series(keep_mask))

        if n_singletons_dropped > 0:
            print(f"  Dropped {n_singletons_dropped:,} singleton observations.")

    # ------------------------------------------------------------------ #
    # 3. Extract arrays
    # ------------------------------------------------------------------ #
    y_np = np.ascontiguousarray(df[y_col].to_numpy(), dtype=np.float64)
    ybar = float(y_np.mean())
    ss_total_overall_pre = float(((y_np - ybar) ** 2).sum())
    X_np = np.ascontiguousarray(df.select(x_cols).to_numpy(), dtype=np.float64)
    n, k = X_np.shape

    # ------------------------------------------------------------------ #
    # 4. Within-demean (or add intercept for plain OLS)
    # ------------------------------------------------------------------ #
    if fe_cols:
        fe_ids = _make_fe_ids(df)
        G_fe_max = int(fe_ids.max()) + 1
        fe_counts = _demean_inplace(X_np, y_np, fe_ids, G_fe_max)
        G_fe = int(np.count_nonzero(fe_counts))
    else:
        G_fe = 0
        if "const" not in x_cols:
            X_np = np.column_stack([np.ones(n, dtype=np.float64), X_np])
            x_cols = ["const"] + list(x_cols)
            k = X_np.shape[1]

    # ------------------------------------------------------------------ #
    # 5. Core OLS
    # ------------------------------------------------------------------ #
    XtX = X_np.T @ X_np
    Xty = X_np.T @ y_np
    XtX_inv = np.linalg.inv(XtX)
    beta_hat = XtX_inv @ Xty
    u_hat = y_np - X_np @ beta_hat

    # ------------------------------------------------------------------ #
    # 6. Variance estimation — fixest-style nonnested correction
    # ------------------------------------------------------------------ #
    def _factorize(series: pl.Series) -> tuple[np.ndarray, int]:
        ids, _ = _series_to_codes(series)
        g_actual = int(np.count_nonzero(np.bincount(ids)))
        return ids, g_actual

    _c1_ids_cached = None
    _c2_ids_cached = None
    if cluster1_col:
        _c1_ids_cached, _ = _factorize(df[cluster1_col])
    if cluster2_col:
        _c2_ids_cached, _ = _factorize(df[cluster2_col])

    def _compute_fe_dof_adj(fe_ids_arr: np.ndarray) -> int:
        """Return number of FE dof to subtract from n-k for the CRF denominator."""
        if _c1_ids_cached is None and _c2_ids_cached is None:
            return G_fe
        if _c1_ids_cached is not None and _is_nested_np(fe_ids_arr, _c1_ids_cached):
            return 0
        if _c2_ids_cached is not None and _is_nested_np(fe_ids_arr, _c2_ids_cached):
            return 0
        return G_fe

    if fe_cols:
        fe_dof_adj = _compute_fe_dof_adj(fe_ids)
    else:
        fe_dof_adj = 0

    dof_resid = max(n - k - fe_dof_adj, 1)

    def _crf_factor(G: int) -> float:
        return (G / (G - 1)) * ((n - 1) / dof_resid)

    if cluster1_col and cluster2_col:
        c1_ids = _c1_ids_cached
        c2_ids = _c2_ids_cached
        G1 = int(np.count_nonzero(np.bincount(c1_ids)))
        G2 = int(np.count_nonzero(np.bincount(c2_ids)))

        c12_combined = c1_ids.astype(np.int64) * (int(c2_ids.max()) + 1) + c2_ids
        _, c12_ids = np.unique(c12_combined, return_inverse=True)
        c12_ids = c12_ids.astype(np.intp)
        G12 = int(np.count_nonzero(np.bincount(c12_ids)))

        S1  = _cluster_score_sum(X_np, u_hat, c1_ids,  int(c1_ids.max()) + 1)
        S2  = _cluster_score_sum(X_np, u_hat, c2_ids,  int(c2_ids.max()) + 1)
        S12 = _cluster_score_sum(X_np, u_hat, c12_ids, int(c12_ids.max()) + 1)

        meat = (
            _crf_factor(G1)  * (S1.T  @ S1)
          + _crf_factor(G2)  * (S2.T  @ S2)
          - _crf_factor(G12) * (S12.T @ S12)
        )

    elif cluster1_col:
        c1_ids = _c1_ids_cached
        G1 = int(np.count_nonzero(np.bincount(c1_ids)))
        S1 = _cluster_score_sum(X_np, u_hat, c1_ids, int(c1_ids.max()) + 1)
        meat = _crf_factor(G1) * (S1.T @ S1)

    else:
        scores = X_np * u_hat[:, np.newaxis]
        meat = scores.T @ scores
        del scores

    # Free heavy intermediates before the rest of the computation.
    ss_resid = float((u_hat ** 2).sum())
    ss_total_within = float((y_np ** 2).sum())
    del X_np, u_hat
    gc.collect()

    vcov = XtX_inv @ meat @ XtX_inv
    se = np.sqrt(np.diag(vcov))

    # ------------------------------------------------------------------ #
    # 7. R², RMSE, degrees of freedom
    # ------------------------------------------------------------------ #
    dof_resid_full = max(n - k - G_fe, 1)
    ss_total_overall = ss_total_overall_pre
    r2_overall = 1.0 - ss_resid / ss_total_overall if ss_total_overall > 0 else np.nan
    r2_within = 1.0 - ss_resid / ss_total_within if ss_total_within > 0 else np.nan
    rmse = float(np.sqrt(ss_resid / dof_resid_full)) if dof_resid_full > 0 else np.nan

    # ------------------------------------------------------------------ #
    # 8. Inference
    # ------------------------------------------------------------------ #
    if cluster1_col and cluster2_col:
        dof_t = min(G1, G2) - 1
    elif cluster1_col:
        dof_t = G1 - 1
    else:
        dof_t = dof_resid

    dof_t = max(dof_t, 1)
    t_stats = beta_hat / se
    pvals = 2 * (1 - stats.t.cdf(np.abs(t_stats), df=dof_t))
    crit = stats.t.ppf(0.975, df=dof_t)
    ci_low  = beta_hat - crit * se
    ci_high = beta_hat + crit * se

    # ------------------------------------------------------------------ #
    # 9. Summary DataFrame with natural sort
    # ------------------------------------------------------------------ #
    summary_df = pd.DataFrame({
        "Coefficient": list(x_cols),
        "Estimate":    beta_hat,
        "Std. Error":  se,
        "t value":     t_stats,
        "Pr(>|t|)":    pvals,
        "2.5%":        ci_low,
        "97.5%":       ci_high,
    })

    def _sort_key(name: str):
        m = re.match(r'^(.*?)(\d+)$', name)
        if m:
            return (m.group(1), int(m.group(2)))
        return (name, 10 ** 9)

    coef_list = list(x_cols)
    keys = [_sort_key(c) for c in coef_list]
    if "const" in coef_list:
        const_pos = coef_list.index("const")
        non_const = [(i, k) for i, k in enumerate(keys) if coef_list[i] != "const"]
        order = [const_pos] + [i for i, _ in sorted(non_const, key=lambda x: x[1])]
    else:
        order = [i for i, _ in sorted(enumerate(keys), key=lambda x: x[1])]

    summary_df = summary_df.iloc[order].reset_index(drop=True)

    # ------------------------------------------------------------------ #
    # 10. Print
    # ------------------------------------------------------------------ #
    nested_note = " (FE nested in cluster → FE dof not subtracted)" if fe_dof_adj == 0 and G_fe > 0 and cluster1_col else ""
    print("\nEstimation:  OLS")
    if fe_cols:
        print(f"Dep. var.: {y_col}   Fixed effects: {', '.join(fe_cols)}")
    else:
        print(f"Dep. var.: {y_col}")
    if cluster1_col and cluster2_col:
        print(f"Inference:  Two-way CRV1 ({cluster1_col}, {cluster2_col})  |  dof = min(G1,G2)-1 = {dof_t}{nested_note}")
    elif cluster1_col:
        print(f"Inference:  CRV1 ({cluster1_col})  |  clusters = {G1}  |  dof = {dof_t}{nested_note}")
    else:
        print("Inference:  HC0 (White robust)")
    print(f"Observations: {n:,}   FE groups: {G_fe:,}   dof_resid (SE): {dof_resid:,}\n")
    print(summary_df.to_markdown(index=False, floatfmt=".3f"))
    print(f"\nRMSE: {rmse:.3f}   R² (overall): {r2_overall:.3f}   R² (within): {r2_within:.3f}")

    return {
        "beta":               beta_hat,
        "se":                 se,
        "t_stats":            t_stats,
        "vcov":               vcov,
        "x_cols":             list(x_cols),
        "y_col":              y_col,
        "fe_col":             fe_cols if fe_cols else None,
        "cluster1_col":       cluster1_col,
        "cluster2_col":       cluster2_col,
        "R2_overall":         r2_overall,
        "R2_within":          r2_within,
        "RMSE":               rmse,
        "dof_resid":          dof_resid,
        "dof_resid_full":     dof_resid_full,
        "fe_dof_adj":         fe_dof_adj,
        "dof_t":              dof_t,
        "n":                  n,
        "k":                  k,
        "G_fe":               G_fe,
        "G1":                 G1 if cluster1_col else None,
        "G2":                 G2 if cluster2_col else None,
        "n_singletons_dropped": n_singletons_dropped,
        "summary_df":         summary_df,
    }


# ──────────────────────────────────────────────────────────────────────────
# Dummy-variable helpers
# ──────────────────────────────────────────────────────────────────────────

def add_dummies(df: pl.DataFrame, cat_vars: list[str]):
    """
    Create and add dummy variables for each categorical variable in cat_vars.
    Returns (df_with_dummies, labels), where labels excludes the first
    alphabetically sorted dummy per categorical variable.

    Sorting is case-insensitive (A == a) and labels are of the form var_category.
    """
    all_dummy_exprs = []
    labels = []

    for var in cat_vars:
        cats = sorted(df[var].unique().to_list(), key=lambda x: str(x).lower())

        for cat in cats:
            colname = f"{var}_{cat}"
            all_dummy_exprs.append((pl.col(var) == cat).cast(pl.Int8).alias(colname))

        # labels: skip the first (alphabetically smallest) dummy
        labels.extend([f"{var}_{cat}" for cat in cats[1:]])

    df = df.with_columns(all_dummy_exprs)

    return df, labels


def add_dummy_cols(df: pl.DataFrame, cat_vars: list[str]):
    """
    Return only the dummy-column labels (without modifying df) for each
    categorical variable in cat_vars. Labels exclude the first alphabetically
    sorted category per variable.

    Sorting is case-insensitive (A == a) and labels are of the form var_category.
    """
    labels = []

    for var in cat_vars:
        cats = sorted(df[var].unique().to_list(), key=lambda x: str(x).lower())
        labels.extend([f"{var}_{cat}" for cat in cats[1:]])

    return labels
