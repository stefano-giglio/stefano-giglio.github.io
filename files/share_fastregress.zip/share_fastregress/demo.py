"""
demo.py — minimal demonstration of `fast_regress3` from `export_fastregress`.

Reads a small parquet file (`demo_data.parquet`) extracted
from a Florida building-permits panel, demonstrates how to:

    1. expand a categorical variable into dummies with `add_dummies`
       (and how to get the dummy labels alone with `add_dummy_cols`)
    2. run an FE-OLS regression with cluster-robust standard errors
       using `fast_regress3`
    3. compare the result against `pyfixest.feols`

Run with:
    python demo.py

Required packages: polars, numpy, pandas, numba, scipy, pyfixest.
"""
import time

import polars as pl
import pyfixest as pf

from export_fastregress import fast_regress3, add_dummies, add_dummy_cols


# ──────────────────────────────────────────────────────────────────────────
# 1. Load the small demo dataset
# ──────────────────────────────────────────────────────────────────────────
df = pl.read_parquet("demo_data.parquet")
print(f"Loaded demo dataset: N = {len(df):,} rows")
print(df.head())
print()

# ──────────────────────────────────────────────────────────────────────────
# 2. Build dummy variables for `party_group`.
#
#    `add_dummies` returns (df_with_dummies, labels). The labels exclude the
#    alphabetically-first category (treated as the omitted baseline).
#
#    `add_dummy_cols` returns just the labels — useful when the dummies are
#    already on the dataframe and you only need the column names.
# ──────────────────────────────────────────────────────────────────────────
df, party_dummies = add_dummies(df, ["party_group"])
print(f"party_group dummies (baseline omitted): {party_dummies}")

# Same labels, no df modification:
labels_only = add_dummy_cols(df, ["party_group"])
print(f"add_dummy_cols returns the same labels:  {labels_only}")
print()

# ──────────────────────────────────────────────────────────────────────────
# 3. Run fast_regress3:  any_permit = α + β·party_group | zip_year FE
#                        with one-way clustering at zip
# ──────────────────────────────────────────────────────────────────────────
print("=" * 72)
print("fast_regress3 result")
print("=" * 72)
t0 = time.perf_counter()
res = fast_regress3(
    df,
    y_col="any_permit",
    x_cols=party_dummies,
    fe_col=["zip_year"],
    cluster1_col="zip",
)
t_fr3 = time.perf_counter() - t0
print(f"\nfast_regress3 elapsed: {t_fr3:.3f} s")

# ──────────────────────────────────────────────────────────────────────────
# 4. Same regression in pyfixest, for comparison.
#    pyfixest expands the `party_group` factor on its own, so we don't need
#    to pass the dummies explicitly.
# ──────────────────────────────────────────────────────────────────────────
print()
print("=" * 72)
print("pyfixest.feols result (same model)")
print("=" * 72)
df_pd = df.to_pandas()
t0 = time.perf_counter()
pf_res = pf.feols(
    "any_permit ~ party_group | zip_year",
    data=df_pd,
    vcov={"CRV1": "zip"},
)
t_pf = time.perf_counter() - t0
print(pf_res.summary())
print(f"\npyfixest.feols elapsed: {t_pf:.3f} s")
print(f"\nspeedup: fast_regress3 is {t_pf / t_fr3:.1f}x faster")
